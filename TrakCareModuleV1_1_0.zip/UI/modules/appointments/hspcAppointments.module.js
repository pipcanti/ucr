/**
 *  Created by sroux on 1/08/2020.
 */

( function() {

  'use strict';

  angular
    .module( 'hspcAppointments', ['ui.router', 'isc.common'] )

    // use MyAppointments from TC appointements (else health records)
    .constant( 'useTCAppointments', true )

    /* @ngInject */
    .config( function( iscStateProvider, $urlRouterProvider, useTCAppointments ) {
      iscStateProvider.state( getStates( useTCAppointments ) );
      $urlRouterProvider.when( '/appointments', destroySessionIfActivating );

      /* @ngInject */
      function destroySessionIfActivating( iscSessionModel, iscCookieManager ) {
        // if redirected here from partway through activation, destroy that temporary session
        if ( iscSessionModel.isActivatingUser() ) {
          iscCookieManager.set( 'noRedirect', 1 );
          iscSessionModel.destroy();
        }
        return 'appointments/myAppointments';
      }
    } );

  function getStates( useTCAppointments ) {
    return {
      'authenticated.appointments': {
        url           : 'appointments',
        state         : 'authenticated.appointments',
        templateUrl   : 'layout/secondaryNavigation.html',
        translationKey: 'ISC_APPOINTMENTS',
        controller    : 'secondaryNavigationController as secondNavCtrl',
        roles         : ['user', 'proxy'],
        displayOrder  : 6,
        resolve       : /* @ngInject */ {
          languageService: function( hspcLanguageService ) {
            return hspcLanguageService;
          },
          secondLevelTabs: function( iscNavContainerModel, languageService ) {
            var tabs = [
              {
                translationKey: 'ISC_MY_APPOINTMENTS',
                state         : 'authenticated.appointments.myAppointments',
                displayOrder  : 0
              },
              {
                translationKey: 'ISC_BOOK_APPOINTMENT_TITLE',
                state         : 'authenticated.appointments.bookAppointment',
                displayOrder  : 1
              }
            ];

            iscNavContainerModel.setSecondaryNav( tabs );

            return tabs;
          },

          secondLevelTasks: function( iscNavContainerModel ) {
            iscNavContainerModel.setSecondaryNavTasks( [] );
            return [];
          }
        }
      },

      'authenticated.appointments.myAppointments': useTCAppointments ? {
        url        : '/myAppointments',
        state      : 'authenticated.appointments.myAppointments',
        templateUrl: 'appointments/myTCAppointments/hspcMyTCAppointments.html',
        controller : 'hspcMyTCAppointmentsController as myTCAppointmentsCtrl',
        roles      : ['user', 'proxy'],
        resolve    : /* @ngInject */ {
          apiTableData: function( $state, hspcMyTCAppointmentsDataService, hspcModalService ) {
            return hspcMyTCAppointmentsDataService.fetchAppointments().then( function( response ) {
              return response;
            }, function() {
              $state.go( 'authenticated.home' );
              var options = {
                type           : 'alert',
                title          : 'ISC_ALERT_RESPONSE_ERROR',
                message        : 'ISC_APPT_CANNOT_GET_MY_APPTS',
                hideOkButton   : true,
                cancelButtonTxt: 'ISC_OK_BTN'
              };
              hspcModalService.openModal( options );
            } );
          },

          help: function( $log, hspcHelpModel ) {
            return hspcHelpModel.updateHelp( 'appointments', 'home' );
          },

          customContent: function( hspcCustomContentModel ) {
            var contentKeys = [
              'content-my-appointments'
            ];

            return hspcCustomContentModel.getContentItems( contentKeys );
          }
        }
      } : {
        url            : '/myAppointments',
        state          : 'authenticated.appointments.myAppointments',
        templateUrl    : 'healthRecords/workflows/myAppointments/hspcMyAppointments.html',
        controller     : 'hspcHealthRecordsBaseController as mapCtrl',
        roles          : ['user', 'proxy'],
        category       : 'Appointments',
        categoryOrder  : 20,
        data           : {
              model   : 'hspcMyAppointmentsModel',
              helpKeys: {
                table  : 'appointments',
                details: 'appointments' + 'Details',
                define : 'searchResults'
              }
            },
        translationKey : 'ISC_MY_APPOINTMENTS',
        resolve        :  /* @ngInject */ {
          tableData: function( $q, $state, $log, hspcApi, hspcHealthRecordsWorkflowHelper, hspcCordovaHelper, hspcAppSessionStorageHelper, hspcHealthRecordsModel ) {
            if ( !hspcHealthRecordsWorkflowHelper.reinitializeState ) {
              var params    = {},
                  isCordova = hspcCordovaHelper.isCordova();

              if ( isCordova ) {
                params.includeCSPToken = 1;
              }
              return hspcApi.get( { params: params }, 'ehr/category', 'appointments' ).then( function( response ) {
                if ( _.get( response, "error" ) ) {
                  $state.go( 'authenticated.home' );
                  hspcHealthRecordsModel.dataNotReady( response );
                  $q.reject( response );
                  return;
                }
                if ( isCordova ) {    
                  if ( response.CSPToken ) {
                    hspcAppSessionStorageHelper.set( 'CSPToken', response.CSPToken );
                  }

                  // set token if available else reset to empty
                }
                return response;
              } );
            }
            return true;
          },
          model    : function( hspcHealthRecordsWorkflowHelper, tableData ) {
            if ( !tableData ) {
              return false;
            }
            else {
              if ( !hspcHealthRecordsWorkflowHelper.reinitializeState ) {
                hspcHealthRecordsWorkflowHelper.initializeState( tableData.Appointments );
              }
              return true;
            }
          },
          help     : function( hspcHelpModel, hspcHealthRecordsWorkflowHelper ) {
            if ( !hspcHealthRecordsWorkflowHelper.reinitializeState ) {
              hspcHelpModel.updateHelp( 'healthRecords', 'appointments' );
            }
          }
        }
      },
	  
      'authenticated.appointments.bookAppointment': {
          url        : '/bookAppointment',
          state      : 'authenticated.appointments.bookAppointment',
          templateUrl: 'appointments/bookAppointment/hspcBookAppointment.html',
          controller : 'hspcBookAppointmentController as baCtrl',
          roles      : ['user', 'proxy'],
          params     : {
            fromState : null,
            params    : null
          },
          resolve    : /* @ngInject */{
            allApptServices: function( $state, hspcModalService, hspcBookAppointmentDataService ) {
              return hspcBookAppointmentDataService.fetchServices().then( function( response ) {
                  return response;
                }, function() {
                $state.go( 'authenticated.home' );
                var options = {
                  type           : 'alert',
                  title          : 'ISC_ALERT_RESPONSE_ERROR',
                  message        : 'ISC_APPT_CANNOT_BOOK_APPT',
                  hideOkButton   : true,
                  cancelButtonTxt: 'ISC_OK_BTN'
                };
                hspcModalService.openModal( options );
              } );
            },
            help           : function( hspcHelpModel ) {
              return hspcHelpModel.updateHelp( 'appointments', 'book-1' );
            },          
            customContent  : function( hspcCustomContentModel ) {
              var contentKeys = [
                    'content-appointments-book-1',
                    'content-appointments-book-2',
                    'content-appointments-book-3'
              ];

              return hspcCustomContentModel.getContentItems( contentKeys );
            },
            // centralize here custom things, could be moved to workbench in further version
            customConfig : function() {
              return {
                bookingHiddenDays         : { sunday : true },
                bookingInitialDisplayRows : 10,
                bookingInitialFetchRows   : 20,
                bookingFullFetchRows      : 50,
                bookingTimeRanges         : [ 
                  { start : "",      end : "10:00" },
                  { start : "",      end : "13:00" },
                  { start : "12:00", end : "14:00" },
                  { start : "13:00", end : "" },
                  { start : "17:00", end : "" }]
              };
            }

          }
        }

    };
  }
} )();
