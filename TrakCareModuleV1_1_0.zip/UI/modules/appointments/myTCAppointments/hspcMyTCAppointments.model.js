/**
 *  Created by sroux on 1/08/2020.
 */

( function() {
  'use strict';

  var hspcMyTCAppointmentsModel = {

    tableConfig: {
      rowTemplate: 'app/templates/tableRow.html',
      rowsOnPage : 10,
      columns    : [
        {
          key  : 'Timestamp',
          title: 'ISC_DATE',
          type : 'dateWithTime'
        },
        {
          key  : 'ServiceDescription',
          title: 'ISC_APPT_SERVICE'
        },
        {
          key  : 'ResourceDescription',
          title: 'ISC_PROVIDER'
        },
        {
          key  : 'HospitalDescription',
          title: 'ISC_CLINIC'
        },
        {
          key  : 'LocationDescription',
          title: 'ISC_LOCATION'
        },
        {
          key  : 'StatusDescription',
          title: 'ISC_STATUS'
        },
        {
          key     : 'Action',
          type    : 'template',
          template: 'appointments/templates/apptActions.html',
          title   : 'ISC_ACTION'
        }]
    }
  };

  angular.module( 'hspcAppointments' )
    .constant( 'hspcMyTCAppointmentsModel', hspcMyTCAppointmentsModel );

} )();
