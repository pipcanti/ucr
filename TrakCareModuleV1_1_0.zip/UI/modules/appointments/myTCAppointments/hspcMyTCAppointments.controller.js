/**
 *  Created by sroux on 1/08/2020.
 */

( function() {

  'use strict';

  angular.module( 'hspcAppointments' )
    .controller( 'hspcMyTCAppointmentsController', hspcMyTCAppointmentsController );

  function hspcMyTCAppointmentsController( devlog,
    $state,
    $rootScope,
    apiTableData,
    hspcMyTCAppointmentsModel,
    hspcUserRoleHelper,
    hspcCustomContentModel,
    hspcMyTCAppointmentsDataService,
    MODAL_EVENTS ) {

    var log = devlog.channel( 'hspcMyTCAppointments', 'hspcMyTCAppointmentsController' );
    log.debug( 'hspcMyTCAppointmentsController LOADED' );

    // ----------------------------
    // vars
    // ----------------------------
    var self = this;

    angular.extend( self, {
      myTCAppointmentsContent: hspcCustomContentModel.getCustomContentItem( 'content-my-tcappointments' ),
      tableConfig            : hspcMyTCAppointmentsModel.tableConfig,
      tableData              : [],
      proxyTitle             : hspcUserRoleHelper.getProxyTitle( 'ISC_MY_APPOINTMENTS' ),
      setTableData           : setTableData,
      handleApptActions      : handleApptActions,
      cancelAppt             : cancelAppt,
      rebookAppt             : rebookAppt
    } );

    // ensure that we update the table data
    self.setTableData( apiTableData );

    function setTableData( tableData ) {
      self.tableData = tableData;
    }

    function cancelAppt( appt ) {
      hspcMyTCAppointmentsDataService.cancelAppointment( appt, "" ).then( function( response ) {
        $state.reload();
        var popupOptions = {
          title           : 'ISC_APPT_CANCEL_ALERT_TITLE',
          message         : 'ISC_APPT_CANCEL_DONE',
          hideCancelButton: true,
          okCallback      : _.noop
        };
        $rootScope.$broadcast( MODAL_EVENTS.showAlertPopup, popupOptions );
      }, onError );

    }

    function onError( response ) {
      var popupOptions = {
        title           : 'ISC_APPT_CANCEL_ALERT_ERR_TITLE',
        message         : 'ISC_APPT_CANCEL_ALERT_ERR',
        hideCancelButton: true,
        okCallback      : _.noop
      };

      $rootScope.$broadcast( MODAL_EVENTS.showAlertPopup, popupOptions );
    }

    function rebookAppt( appt ) {
      return $state.go( 'authenticated.appointments.bookAppointment', {
        "params": {
          "ServiceDescription" : appt.ServiceDescription,
          "ProviderDescription": appt.ResourceDescription,
          "LocationDescription": appt.LocationDescription,
          "HospitalDescription": appt.HospitalDescription
        }
      }
      );
    }

    function handleApptActions( state ) {
      if ( state.name === "cancel" ) {
        var popupOptions = {
          title           : 'ISC_APPT_CANCEL_ALERT_TITLE',
          message         : 'ISC_APPT_CANCEL_ALERT',
          hideCancelButton: false,
          okCallback      : function() {
            self.cancelAppt( state.data );
          }
        };
        $rootScope.$broadcast( MODAL_EVENTS.showAlertPopup, popupOptions );
      }
      if ( state.name === "rebook" ) {
        self.rebookAppt( state.data );
      }
    }

  }// END CLASS

} )();
