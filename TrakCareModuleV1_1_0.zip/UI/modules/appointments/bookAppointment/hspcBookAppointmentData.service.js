/**
 * Created by sroux on 1/08/2020.
 */

( function() {
  'use strict';

  angular
    .module( 'hspcAppointments' )
    .factory( 'hspcBookAppointmentDataService', hspcBookAppointmentDataService );

  /* @ngInject */
  function hspcBookAppointmentDataService( devlog,
    hspcApi
  ) {

    var log = devlog.channel( 'hspcBookAppointmentDataService' );
    log.logFn( 'LOADED' );

    var service = {
      fetchServices : fetchServices,
      fetchResources: fetchResources,
      fetchSlots    : fetchSlots,
      lockSlot      : lockSlot,
      unlockSlot    : unlockSlot,
      confirmSlot   : confirmSlot
    };

    return service;

    // ----------------------------

    function fetchServices() {
      return hspcApi.get( { }, 'trakcare/booking/services' ).then( function( response ) {
        return response;
      } );
    }

    function fetchResources( specialty, service ) {
      var params = {};
      if ( specialty ) { 
        params.SpecialtyID = specialty.ID; 
      }
      if ( service ) { 
        params.ServiceID = service.ServiceID; 
        params.OrderItemID = service.OrderItemID; 
      }      

      return hspcApi.get( { params: params }, 'trakcare/booking/resources' ).then( function( response ) {
        return response;
      } );
    }

    function fetchSlots( service, location, hospital, provider, datefilters, rows ) {
      var params = {};
      if ( service ) { 
        params.ServiceID = service.ServiceID; 
        params.OrderItemID = service.OrderItemID; 
      }

      // TC API is based on location and resource, we use hospital and provider, so do the mapping here.
      var LocIDs = [];
      var ResIDs = [];
      if ( location ) { 
        LocIDs = [location.ID]; 
      }
      else if ( hospital ) { 
        LocIDs = hospital.locations.map( function( key ) {
          return key.ID;
        } );
      }
      if ( provider ) {
        // filter resource ids matching locs
        if ( LocIDs.length ) {
          ResIDs = LocIDs.reduce( function( filtered, locID ) {
            var resource = _.find( provider.resources, { LocationID: locID } );
            if ( resource ) {
              filtered.push( resource.ID ); 
            }
            return filtered;
          }, [] );
        }
        else {
          // all resource ids from that provider
          ResIDs = provider.resources.map( function( key ) {
              return key.ID;
            } );
        }
        params.ResourceID = ResIDs.join();
      }
      else {
        params.LocationID = LocIDs.join();
      }
      if ( datefilters ) {
        if ( datefilters.startTime ) {
          params.StartTime = datefilters.startTime;
        }
        if ( datefilters.endTime ) {
          params.EndTime = datefilters.endTime;
        }
        if ( datefilters.startDate ) {
          params.StartDate = datefilters.startDate;
        }
        if ( datefilters.endDate ) {
          params.EndDate = datefilters.endDate;
        }
        if ( datefilters.fetchNextAvailable ) {
          params.FetchNextAvailable = datefilters.fetchNextAvailable;
        }
        var daysOfWeek = ( datefilters.monday ? "1" : "" ) + ( datefilters.tuesday ? "2" : "" ) + ( datefilters.wednesday ? "3" : "" ) + ( datefilters.thursday ? "4" : "" );
        daysOfWeek += ( datefilters.friday ? "5" : "" ) + ( datefilters.saturday ? "6" : "" ) + ( datefilters.sunday ? "7" : "" );
        if ( daysOfWeek ) {
          params.DaysOfWeek = daysOfWeek;
        }        
      }
      if ( rows ) { 
        params.Rows = rows; 
      }

      return hspcApi.get( { params: params }, 'trakcare/booking/slots' ).then( function( response ) {       
        return response;
      } );
    }

    function toggleSlot( slot, lock ) {
      var params = {};
      params.Slot = {
        UniqueSlotRefNum    : slot.UniqueSlotRefNum,
        UniqueBookingRefNum : slot.UniqueBookingRefNum,
        ServiceID           : slot.ServiceID,
        OrderItemID         : slot.OrderItemID
      };
      params.Action = lock ? "Lock" : "Unlock";
      return hspcApi.post( { data: params }, 'trakcare/booking/slots/' + slot.UniqueSlotRefNum ).then( function( response ) {
        return response;
      } );
    }

    function lockSlot( slot ) {
      return toggleSlot( slot, 1 );
    }

    function unlockSlot( slot ) {
      return toggleSlot( slot, 0 );
    }

    function confirmSlot( slot, patientMsg ) {
      var params = {};
      params.Slot = {
        UniqueSlotRefNum    : slot.UniqueSlotRefNum,
        UniqueBookingRefNum : slot.UniqueBookingRefNum,
        ServiceID           : slot.ServiceID,
        OrderItemID         : slot.OrderItemID
      };
      params.Remarks = patientMsg;
      params.Action = "Confirm";
      return hspcApi.post( { data: params }, 'trakcare/booking/slots/' + slot.UniqueSlotRefNum ).then( function( response ) {
        return response;
      } );
    }

  }//END CLASS

} )();
