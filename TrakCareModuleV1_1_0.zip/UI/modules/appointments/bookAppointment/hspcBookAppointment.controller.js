/**
 *  Created by sroux on 1/08/2020.
 */

( function() {

  'use strict';

  angular.module( 'hspcAppointments' )
    .controller( 'hspcBookAppointmentController', hspcBookAppointmentController );

  function hspcBookAppointmentController( devlog,
    $timeout,
    $state,
    $stateParams,
    $scope,
    $rootScope,
    $filter,
    hspcBookAppointmentModel,
    hspcDatepickerService,
    hspcLanguageService,
    hspcCustomContentModel,
    hspcHelpModel,
    hspcBookAppointmentDataService,
    HELP_EVENTS,
    MODAL_EVENTS,
    allApptServices,
    customConfig ) {

    var log = devlog.channel( 'hspcBookAppointment', 'hspcBookAppointmentController' );
    log.debug( 'hspcBookAppointmentController LOADED' );

    // ----------------------------
    // vars
    // ----------------------------
    var self = this;

    angular.extend( self, {
      incomplete            : true,
      complete              : true,
      selectedIndex         : 0,
      totalStepCount        : 3,
      showEmergencyWarning  : false,
      calendarEventSources  : [],
      startOver             : startOver,
      isCurrentStepDone     : isCurrentStepDone,
      isWorkflowComplete    : isWorkflowComplete,
      onSelectService       : onSelectService,
      onSelectSpecialty     : onSelectSpecialty,
      onSelectHospital      : onSelectHospital,
      onSelectSlot          : onSelectSlot,
      onInitSlotsStep       : onInitSlotsStep,
      getServicesModel      : getServicesModel,
      getOptionsModel       : getOptionsModel,
      getSlotsModel         : getSlotsModel,
      getConfirmModel       : getConfirmModel,
      getCalendarEvents     : getCalendarEvents,
      getFilterProviders    : getFilterProviders,
      getFilterServices     : getFilterServices,
      currentStateModel     : currentStateModel,
      confirm               : confirm,
      updateCalendarConfig  : updateCalendarConfig,
      getNextAppointmentSlot: getNextAppointmentSlot,
      formatTimeRange       : formatTimeRange,
      refreshCalNextAvDate  : refreshCalNextAvDate,
      fetchMoreSlots        : fetchMoreSlots,
      answerCalendar        : answerCalendar ,
      onCalendarEventClick  : onCalendarEventClick,
      updateHelp            : updateHelp,
      startDateConfig       : {},
      bookapp1              : hspcCustomContentModel.getCustomContentItem( 'content-appointments-book-1' ),
      bookapp2              : hspcCustomContentModel.getCustomContentItem( 'content-appointments-book-2' ),
      bookapp3              : hspcCustomContentModel.getCustomContentItem( 'content-appointments-book-3' )
    } );

    self.confirmText = "ISC_CONFIRM";
    self.selectedIndex = hspcBookAppointmentModel.getSelectedIndex();
    self.totalStepCount = hspcBookAppointmentModel.getTotalStepCount();
    self.startOver();

    // init workflow
    function startOver() {
      // if reinit (when coming from help), just do nothing...
      if ( hspcBookAppointmentModel.reinitializeState ) {
        hspcBookAppointmentModel.reinitializeState = false;
        return;
      }
      var currentSlot = self.getSlotsModel().selectedSlot;
      if ( currentSlot ) {
        hspcBookAppointmentDataService.unlockSlot( currentSlot );
      }
      self.getSlotsModel().selectedSlot = null;
      hspcBookAppointmentModel.resetSteps();
      self.selectedIndex = 0;

      //configure hidden days
      self.getOptionsModel().hiddenDays = _.get( customConfig, 'bookingHiddenDays', { sunday: true } );
      self.getOptionsModel().timeRanges = _.get( customConfig, 'bookingTimeRanges', [] );

      self.getSlotsModel().initialFetchRows = _.get( customConfig, 'bookingInitialFetchRows', '20' );
      self.getSlotsModel().initialDisplayRows = _.get( customConfig, 'bookingInitialDisplayRows', '10' );
      self.getSlotsModel().fullFetchRows = _.get( customConfig, 'bookingFullFetchRows', '50' );

      // all service data fetched in injected 'allApptServices'
      hspcBookAppointmentModel.setMatchingSpecialties( allApptServices.Specialties );
      hspcBookAppointmentModel.setMatchingServices( allApptServices.Services );

      // update max date from config
      if ( allApptServices.ConfigBookingMaxDate ) {
        self.getServicesModel().maxDate = allApptServices.ConfigBookingMaxDate;
        self.getSlotsModel().maxDate = allApptServices.ConfigBookingMaxDate;
      }
      if ( allApptServices.ConfigBookingMinDate ) {
        self.getServicesModel().minDate = allApptServices.ConfigBookingMinDate;
        self.getSlotsModel().minDate = allApptServices.ConfigBookingMinDate;
      }

      self.startDateConfig = getStartDateConfig();

      var params = $stateParams.params;

      // check if we are in rebook workflow, from state data
      if ( params && params.ServiceDescription ) {
        var specialty = "";
        var service = _.find( self.getServicesModel().matchingServices, { "Description": params.ServiceDescription } );
        if ( service ) {
          var specialties = self.getServicesModel().matchingSpecialties;
          // find specialty providing service, firt when specialty = location
          specialty = _.find( specialties, function( e ) { 
            return ( e.Description === params.LocationDescription ) && _.includes( e.ServiceCodes, service.Code );
          } );
          if ( !specialty ) {
            specialty = _.find( specialties, function( e ) { 
              return _.includes( e.ServiceCodes, service.Code ); 
            } );
          }
        }
        if ( specialty ) {
          self.getServicesModel().selectedSpecialty = specialty;
          self.getServicesModel().selectedService = service;
          // fetch resources to find a match with input provider
          hspcBookAppointmentDataService.fetchResources( getServicesModel().selectedSpecialty, getServicesModel().selectedService ).then( function( response ) {
            hspcBookAppointmentModel.setMatchingResources( response.Resources, response.Locations, response.Hospitals );

            if ( params && params.HospitalDescription ) {
              var hosp = _.find( self.getServicesModel().matchingHospitals, { "Description": params.HospitalDescription } );
              if ( hosp ) {
                self.getServicesModel().selectedHospital = hosp;
              }
            }

            if ( params && params.ProviderDescription ) {
              var prov = _.find( self.getServicesModel().matchingProviders, { "Description": params.ProviderDescription } );
              if ( prov ) {
                self.getServicesModel().selectedProvider = prov;
                self.getServicesModel().showOptions = true;
                self.selectedIndex = 1;
              }
            }
          } );
        }
      } // end rebook
    } //startOver

    function getFilterServices()
    {
      return hspcBookAppointmentModel.filterServices();     
    }

    function getFilterProviders()
    {
      return hspcBookAppointmentModel.filterProviders();
    }

    // ----------------------------	
    function updateHelp() {
      var key = "book-" + ( self.selectedIndex + 1 );
      hspcHelpModel.updateHelp( "appointments", key );
    }

    // startDate picker config
    function getStartDateConfig() {
      var dateFormat = 'L';
      var minDate = self.getServicesModel().minDate;
      var maxDate = self.getServicesModel().maxDate;
      return hspcDatepickerService.getConfig( {
        position   : 'bottom',
        format     : dateFormat,
        minDate    : '"' + ( minDate ? moment( minDate, "YYYY-MM-DD" ).format( dateFormat ) : "" ) + '"',
        maxDate    : '"' + ( maxDate ? moment( maxDate, "YYYY-MM-DD" ).format( dateFormat ) : "" ) + '"',
        startView  : 'month',
        readonly   : false,
        placeholder: $filter( 'translate' )( 'ISC_APPT_GETFROMDATE_PLACEHOLDER' )
      } );
    }

    // workflow template, check can go next step
    function isCurrentStepDone() {
      return hspcBookAppointmentModel.isStepComplete( self.selectedIndex );
    }

    // workflow template, check complete
    function isWorkflowComplete() {
      return hspcBookAppointmentModel.isWorkflowComplete();
    }

    // workflow confirm action, do the booking
    function confirm() {
      hspcBookAppointmentDataService.confirmSlot( self.getSlotsModel().selectedSlot, 
      self.getConfirmModel().ConfirmationComments ).then( function( response ) {
      

        self.getSlotsModel().selectedSlot = null;

        var popupOptions = {
          title             : 'ISC_APPT_BOOKED_ALERT_TITLE',
          message           : 'ISC_APPT_BOOKED_ALERT',
          hideCancelButton  : true,
          okCallback        : _.noop,
          isWorkflowComplete: true
        };

        closeCallback().then(
          function() {
            $rootScope.$broadcast( MODAL_EVENTS.showAlertPopup, popupOptions );
          } );

      }, onError );
    }

    function closeCallback() {
      self.startOver();
      if ( $stateParams.fromState ) {
        return $state.go( $stateParams.fromState.name, $stateParams.fromState.params );
      } else {
        return $state.go( 'authenticated.appointments.myAppointments' );
      }
    }

    function onSelectError( response )
    {
      self.updateCalendarConfig();
    }

    function onError( response ) {
      var popupOptions = {
        title           : 'ISC_APPT_BOOKED_ALERT_TITLE',
        message         : 'ISC_APPT_BOOKED_ALERT_ERR',
        hideCancelButton: true,
        okCallback      : _.noop
      };

      $rootScope.$broadcast( MODAL_EVENTS.showAlertPopup, popupOptions );
    }

    function currentStateModel() {
      return hspcBookAppointmentModel.currentStateModel;
    }

    function getNextAppointmentSlot() {
      return hspcBookAppointmentModel.getSlotsModel().nextAvailableSlot;
    }

    function getServicesModel() {
      return hspcBookAppointmentModel.getServicesModel();
    }
    function getOptionsModel() {
      return hspcBookAppointmentModel.getOptionsModel();
    }
    function getSlotsModel() {
      return hspcBookAppointmentModel.getSlotsModel();
    }
    function getConfirmModel() {
      return hspcBookAppointmentModel.getConfirmModel();
    }

    function onSelectService() {
      hspcBookAppointmentDataService.fetchResources( getServicesModel().selectedSpecialty, getServicesModel().selectedService ).then( function( response ) {
        hspcBookAppointmentModel.setMatchingResources( response.Resources, response.Locations, response.Hospitals );
        getServicesModel().selectedProvider = null;
      } );
    }

    function onSelectSpecialty() {
      getServicesModel().selectedService = null;
    }

    function onSelectHospital() {
      getServicesModel().selectedProvider = null;
    }

    // action on 'next available button'
    function refreshCalNextAvDate( nextDate ) {
      $( "#nextAvailableSlot" ).hide();
      $( '#calendar' ).fullCalendar( 'gotoDate', nextDate );
    }

    // action on 'fetch more button', set indicator and trigger calendar refetch
    function fetchMoreSlots() {
      getSlotsModel().fetchMore = true;
      $( "#calendar" ).fullCalendar( "refetchEvents" );
    }

    // slot selected
    function onSelectSlot( data ) {
      var currentSlot = self.getSlotsModel().selectedSlot;
      if ( currentSlot ) {
        hspcBookAppointmentDataService.unlockSlot( currentSlot );
      }
      self.getSlotsModel().selectedSlot = null;

      hspcBookAppointmentDataService.lockSlot( data ).then( function( response ) {
        self.getSlotsModel().selectedSlot = data;

        // set notes
        data.Notes = response.BookingNotes;

        // find hosp by desc to fill slot data
        var hosp = _.find( self.getOptionsModel().matchingHospitals, { Description: data.HospitalDescription } );
        var location = {};
        Object.assign( location, hosp );
        location.Description = data.LocationDescription;
        location.HospitalDescription = data.HospitalDescription;
        data.Location = location;
        // set friendy date/time
        var nd = moment( data.Date + " " + data.StartTime );
        data.DisplayDate = nd.format( "L" );
        data.DisplayTime = nd.format( "LT" );
        data.ServiceDescription = getServicesModel().selectedService.Description;

        self.selectedIndex = self.selectedIndex + 1;
      }, onSelectError );
    }

    // init slots step
    function onInitSlotsStep() {
      var currentSlot = self.getSlotsModel().selectedSlot;
      if ( currentSlot ) {
        hspcBookAppointmentDataService.unlockSlot( currentSlot );
      }
      self.getSlotsModel().selectedSlot = null;
      // force calendar refresh
      self.updateCalendarConfig();
    }

    function formatTimeRange( timeRange ) {
      if ( !timeRange ) {
        return "";
      }
      var start = timeRange.start ? moment( timeRange.start, "HH:mm" ).format( "LT" ) : "";
      var end = timeRange.end ? moment( timeRange.end, "HH:mm" ).format( "LT" ) : "";
      if ( start && end ) {
        return start + '-' + end;
      }
      if ( start ) {
        return $filter( 'translate' )( 'ISC_APPT_AFTER_TIME', { time: start } );
      }
      if ( end ) {
        return $filter( 'translate' )( 'ISC_APPT_BEFORE_TIME', { time: end } );
      }
      return "";
    }

    // return data to calendar callback
    function answerCalendar( callback, startMoment, endMoment, maxCount ) {
      var slotModel = self.getSlotsModel();
      var hasMoreData = false;
      var calendarEvents = [];
      var nextAvail = "";
      for ( var iMoment = moment( startMoment ); iMoment.isSameOrBefore( endMoment, 'd' ); iMoment.add( 1, 'd' ) ) {
        var fetchInfo = slotModel.dateFetchInfos[iMoment.format( 'YYYY-MM-DD' )];
        if ( maxCount > 0 ) {
          if ( ( !fetchInfo.complete ) || ( fetchInfo.events.length > maxCount ) ) {
            hasMoreData = true;
          }
          var n = maxCount < fetchInfo.events.length ? maxCount : fetchInfo.events.length;
          for ( var j = 0; j < n; j++ ) {
            calendarEvents.push( fetchInfo.events[j] );
          }
        }
        else {
          Array.prototype.push.apply( calendarEvents, fetchInfo.events );
        }
        nextAvail = fetchInfo.nextAvail;
      }

      // update navigation hints
      if ( nextAvail ) {
        nextAvail.DisplayDate = moment( nextAvail.Date, 'YYYY-MM-DD' ).format( "L" );
      }
      hspcBookAppointmentModel.setNextAvailableSlotModel( nextAvail );
      self.getSlotsModel().hasMoreData = hasMoreData;

      // callback from fullcalendar.js
      callback( calendarEvents );

      // need to show outside so digest apply, use a timeout call
      if ( calendarEvents.length === 0 ) {
        if ( nextAvail ) {
          $timeout( function() { $( "#nextAvailableSlot" ).show(); }, 0 );
        }
        else {
          $( "#noSlots" ).show();
        }
      }
      else {
        if ( hasMoreData ) {
          $( "#fetchMoreSlots" ).show();
        }
      }
    }

    // calendar event clicked
    function onCalendarEventClick( event ) {
      self.onSelectSlot( event.data );
    }

    // This function applies configs and triggers a full rebuild of the calendar object.
    function updateCalendarConfig() {
      var hiddenDays = [];
      var hasInvisibleDay = getOptionsModel().monday || getOptionsModel().tuesday || getOptionsModel().wednesday || getOptionsModel().thursday || getOptionsModel().friday || getOptionsModel().saturday || getOptionsModel().sunday;
      if ( ( getOptionsModel().hiddenDays.sunday ) || ( ( hasInvisibleDay ) && !getOptionsModel().sunday ) ) {
        hiddenDays.push( 0 );
      }
      if ( ( getOptionsModel().hiddenDays.monday ) || ( ( hasInvisibleDay ) && !getOptionsModel().monday ) ) {
        hiddenDays.push( 1 );
      }
      if ( ( getOptionsModel().hiddenDays.tuesday ) || ( ( hasInvisibleDay ) && !getOptionsModel().tuesday ) ) {
        hiddenDays.push( 2 );
      }
      if ( ( getOptionsModel().hiddenDays.wednesday ) || ( ( hasInvisibleDay ) && !getOptionsModel().wednesday ) ) {
        hiddenDays.push( 3 );
      }
      if ( ( getOptionsModel().hiddenDays.thursday ) || ( ( hasInvisibleDay ) && !getOptionsModel().thursday ) ) {
        hiddenDays.push( 4 );
      }
      if ( ( getOptionsModel().hiddenDays.friday ) || ( ( hasInvisibleDay ) && !getOptionsModel().friday ) ) {
        hiddenDays.push( 5 );
      }
      if ( ( getOptionsModel().hiddenDays.saturday ) || ( ( hasInvisibleDay ) && !getOptionsModel().saturday ) ) {
        hiddenDays.push( 6 );
      }
      self.calendarConfig.hiddenDays = hiddenDays;
      // clear event data
      self.getSlotsModel().dateFetchInfos = {};
      self.getSlotsModel().fetchMore = false;
      hspcBookAppointmentModel.setNextAvailableSlotModel( null );
      if ( self.getSlotsModel().currentStateModel.LoadFromCurrentState ) {
        var defaultView = localStorage.getItem( "fcDefaultView" );
        if ( defaultView ) { self.calendarConfig.defaultView = defaultView; }
      }
      var start = localStorage.getItem( "fcDefaultViewStart" );
      if ( start ) { self.calendarConfig.defaultDate = moment( start ); }
      else { delete self.calendarConfig.defaultDate; }
      self.getSlotsModel().currentStateModel.LoadFromCurrentState = 0;
      self.calendarConfig.updateCount = self.calendarConfig.updateCount + 1; // this force a change in config
    }

    // Event source, handle calendar data
    function getCalendarEvents( start, end, timezone, callback ) {
      // not very angular but...
      $( "#nextAvailableSlot" ).hide();
      $( "#fetchMoreSlots" ).hide();
      $( "#noSlots" ).hide();

      var startMoment = moment( start.format( 'YYYY-MM-DD' ) );
      var endMoment = moment( end.format( 'YYYY-MM-DD' ) ).subtract( 1, 'd' );

      var slotModel = getSlotsModel();
      if ( slotModel.maxDate ) {
        var maxMoment = moment( slotModel.maxDate, "YYYY-MM-DD" );
        if ( maxMoment < endMoment ) {
          endMoment = maxMoment;
        }
      }

      var startTime = "";
      var firstFetch = !slotModel.fetchMore; // indicate we are fetching initials rows
      slotModel.fetchMore = false;
      var needFetch = false;
      var empty = true;
      for ( var iMoment = moment( startMoment ); iMoment.isSameOrBefore( endMoment, 'd' ); iMoment.add( 1, 'd' ) ) {
        var dateKey = iMoment.format( 'YYYY-MM-DD' );
        var fetchInfo = slotModel.dateFetchInfos[dateKey];
        if ( !fetchInfo ) {
          // no data fetch for this day
          fetchInfo = { events: [] };
          slotModel.dateFetchInfos[dateKey] = fetchInfo;
          firstFetch = true;
          needFetch = true;
        }
        else {
          // get last slot start time for this day
          if ( fetchInfo.lastStartTime && ( !startTime || ( fetchInfo.lastStartTime < startTime ) ) ) {
            startTime = moment( fetchInfo.lastStartTime, "HH:mm" ).add( 1, "m" ).format( "HH:mm" );
          }
          if ( !fetchInfo.complete && !firstFetch ) { needFetch = true; }
          if ( fetchInfo.events.length > 0 ) { empty = false; }
        }
        
        // force refetch if fully empty and no nextAvail info
        if ( empty && iMoment.isSame( endMoment, 'd' ) && ( !fetchInfo.hasOwnProperty( "nextAvail" ) ) ) {
          needFetch = true;
        }
      }

      var rows = firstFetch ? slotModel.initialFetchRows : slotModel.fullFetchRows;
      var displayRows = firstFetch ? slotModel.initialDisplayRows : -1;

      // answer from cache
      if ( !needFetch ) {
        self.answerCalendar( callback, startMoment, endMoment, displayRows );
        return;
      }

      if ( firstFetch ) {
        // some day is not filled
        startTime = "";
      }
      var endTime = "";

      // allow filtering slots per periode
      if ( getOptionsModel().selectedTimeRange ) {
        if ( !startTime && getOptionsModel().selectedTimeRange.start ) {
          startTime = getOptionsModel().selectedTimeRange.start;
        }
        if ( !endTime && getOptionsModel().selectedTimeRange.end ) {
          endTime = getOptionsModel().selectedTimeRange.end;
        }
      }

      return hspcBookAppointmentDataService.fetchSlots(
        getServicesModel().selectedService,
        getServicesModel().selectedLocation,
        getServicesModel().selectedHospital,
        getOptionsModel().selectedProvider,
        {
          "startTime"         : startTime,
          "endTime"           : endTime,
          "startDate"         : startMoment.format( 'YYYY-MM-DD' ),
          "endDate"           : endMoment.format( 'YYYY-MM-DD' ),
          "monday"            : getOptionsModel().monday,
          "tuesday"           : getOptionsModel().tuesday,
          "wednesday"         : getOptionsModel().wednesday,
          "thursday"          : getOptionsModel().thursday,
          "friday"            : getOptionsModel().friday,
          "saturday"          : getOptionsModel().saturday,
          "sunday"            : getOptionsModel().sunday,
          'fetchNextAvailable': firstFetch
        },
        rows
      ).then( function( response ) {
        var nextAvail = "";
        var countPerDate = {};
        if ( ( firstFetch ) && ( response.Slots.length === 0 ) ) {
          //need to look at reponse.NextAvailableSlot
          if ( response.NextAvailSlot ) {
            nextAvail = response.NextAvailSlot;
          }
        }

        // sets up event properties needed by calendar events
        if ( response.Slots ) {
          _.forEach( response.Slots, function( item ) {
            var date = _.get( item, 'Date' );
            var start = _.get( item, 'StartTime' );
            var startHHMM = _.get( item, 'StartTime' ).substring( 0, 5 );
            var fetchInfo = slotModel.dateFetchInfos[date];
            countPerDate[date] = ( !countPerDate[date] ? 1 : countPerDate[date] + 1 );
            if ( ( !fetchInfo ) || ( startHHMM <= fetchInfo.lastStartTime ) ) { return; }
            fetchInfo.lastStartTime = startHHMM;
            var end = _.get( item, 'EndTime' );
            fetchInfo.events.push( {
              title : "",
              start : start ? date + 'T' + start : date,
              end   : end ? date + 'T' + end : date,
              type  : "",
              data  : item,
              allDay: !end
            } );
          } );
        }
        
        for ( var iMoment = moment( endMoment ); iMoment.isSameOrAfter( startMoment, 'd' ); iMoment.subtract( 1, 'd' ) ) {
          var dateKey = iMoment.format( 'YYYY-MM-DD' );
          var fetchInfo = slotModel.dateFetchInfos[dateKey];
          if ( !fetchInfo ) {
            continue;
          }
          if ( firstFetch && ( fetchInfo.events.length === 0 ) ) { // no slot in day
            if ( iMoment.isSame( endMoment, 'd' ) ) {
              if ( response.Slots.length === 0 ) {
                fetchInfo.nextAvail = nextAvail;
                // we are in last day of initial fetch for performance fill days until next avail, 
                // avoiding useless refetch if user goes through empty
                var nextDate = nextAvail ? nextAvail.Date : slotModel.maxDate;
                if ( nextDate ) {
                  var beforeNextAvail =  moment( nextDate, 'YYYY-MM-DD' ).subtract( 1, 'd' );
                  for ( var iFuturMoment = moment( endMoment ).add( 1, 'd' ); iFuturMoment.isSameOrBefore( beforeNextAvail, 'd' ); iFuturMoment.add( 1, 'd' ) ) {
                    var futurDateKey = iFuturMoment.format( 'YYYY-MM-DD' );
                    var futurFetchInfo = slotModel.dateFetchInfos[futurDateKey];
                    if ( !futurFetchInfo ) {
                      futurFetchInfo = { events: [], nextAvail: nextAvail, complete : true };
                      slotModel.dateFetchInfos[futurDateKey] = futurFetchInfo;
                    }
                    else {
                      futurFetchInfo.nextAvail = nextAvail;
                    }
                  }
                }
              }
            }
            else {
              var nextInfo = slotModel.dateFetchInfos[moment( iMoment ).add( 1, 'd' ).format( 'YYYY-MM-DD' )];
              if ( nextInfo.events.length > 0 ) { 
                fetchInfo.nextAvail = nextInfo.events[0].data; 
              }
              else if ( nextInfo.hasOwnProperty( "nextAvail" ) ) { 
                fetchInfo.nextAvail = nextInfo.nextAvail; 
              }
            }
          }
          // on second fetch or we count more rows
          if ( ( !firstFetch ) || ( !countPerDate[dateKey] ) || ( countPerDate[dateKey] < rows ) ) {
            fetchInfo.complete = true;
          }
        }
        self.answerCalendar( callback, startMoment, endMoment, displayRows );
      } );
    }

    //config for appointment calendar - date selection
    self.calendarConfig = {
      locale: _.get( hspcLanguageService, 'selectedLanguage.fileName', 'en-us' ),
      defaultView: 'basicWeek',
      timeFormat: 'LT',
      lazyFetching: false,
      updateCount: 0,
      timezone : 'local',

      header: {
        left  : 'basicWeek basicDay',
        center: 'title',
        right : 'today prev,next'
      },
      contentHeight: 200,
      eventClick: function( event ) {
        self.onCalendarEventClick( event );
      },
      eventSources: [{
        events: self.getCalendarEvents
      }],
      viewRender: function( view, element ) {
        if ( !self.getSlotsModel().currentStateModel.LoadFromCurrentState ) {
          localStorage.setItem( "fcDefaultViewStart", view.start );
          localStorage.setItem( "fcDefaultView", view.type );
        }
        var minDate = moment().format( 'YYYY-MM-DD' );
        var maxDate = self.getSlotsModel().maxDate;
        var endDate = moment( view.end ).format( 'YYYY-MM-DD' );
        var startDate = moment( view.start ).format( 'YYYY-MM-DD' );
        if ( ( minDate >= endDate ) || ( minDate >= startDate && minDate <= endDate ) ) {
          $( ".fc-prev-button" ).prop( 'disabled', true );
          $( ".fc-prev-button" ).addClass( 'fc-state-disabled' );
          $( ".fc-next-button" ).removeClass( 'fc-state-disabled' );
          $( ".fc-next-button" ).prop( 'disabled', false );
        }
        else if ( maxDate < endDate ) {
          $( ".fc-next-button" ).addClass( 'fc-state-disabled' );
          $( ".fc-next-button" ).prop( 'disabled', true );
          $( ".fc-prev-button" ).removeClass( 'fc-state-disabled' );
          $( ".fc-prev-button" ).prop( 'disabled', false );
        }
        else {
          $( ".fc-prev-button" ).removeClass( 'fc-state-disabled' );
          $( ".fc-prev-button" ).prop( 'disabled', false );
          $( ".fc-next-button" ).removeClass( 'fc-state-disabled' );
          $( ".fc-next-button" ).prop( 'disabled', false );
        }
      }
    };

    // watch on workflow index
    $scope.$watch(
      function() {
        return self.selectedIndex;
      },
      function( newVal ) {
        self.getSlotsModel().currentStateModel.LoadFromCurrentState = ( ( hspcBookAppointmentModel.getSelectedIndex() === 2 ) && ( newVal === 1 ) ) ? 1 : 0;
        hspcBookAppointmentModel.setSelectedIndex( newVal ); // keep the model in sync
        self.updateHelp();

        if ( newVal === 1 ) {
          if ( !self.getSlotsModel().currentStateModel.LoadFromCurrentState ) {
            localStorage.removeItem( "fcDefaultViewStart" );
            if ( self.getServicesModel().startDate ) {
              localStorage.setItem( "fcDefaultViewStart", moment( self.getServicesModel().startDate ) );
            }
          }
          self.onInitSlotsStep();
        }
      }
    ); 

    // on help event, remind reinitializeState so that we will not reset workflow data
    $rootScope.$on( HELP_EVENTS.showHelp, function() {
      hspcBookAppointmentModel.reinitializeState = true;
    } );

    $rootScope.$on( '$stateChangeSuccess', function( event, toState, toParams, fromState, fromParams ) {
      var isFromCalendar = fromState.name === "authenticated.appointments.bookAppointment";
      if ( ( isFromCalendar ) && ( toState.name !== "unauthenticated.info.help" ) && ( getSlotsModel().selectedSlot ) ) {
        self.startOver();
      }
    } );

  }// END CLASS

} )();
