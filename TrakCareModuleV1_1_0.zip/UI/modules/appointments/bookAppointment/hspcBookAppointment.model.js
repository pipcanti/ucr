/**
 * Created by sroux on 1/08/2020.
 */


( function() {
  'use strict';

  function hspcBookAppointmentModel( devlog ) {//jshint ignore:line

    var log = devlog.channel( 'hspcBookAppointmentModel' );
    log.debug( 'hspcBookAppointmentModel LOADED' );

    // ----------------------------
    // vars
    // ----------------------------

    var selectedIndex;
    var totalStepCount;
    var servicesModel;
    var optionsModel;
    var slotsModel;
    var confirmModel;
    var models = [];

    initModels();

    var model = {
      getSelectedIndex          : getSelectedIndex,
      setSelectedIndex          : setSelectedIndex,
      getTotalStepCount         : getTotalStepCount,
      reinitializeState         : false,
      setMatchingSpecialties    : setMatchingSpecialties,
      setMatchingServices       : setMatchingServices,
      setMatchingResources      : setMatchingResources,
      setMatchingSlots          : setMatchingSlots,
      filterProviders           : filterProviders,
      filterServices            : filterServices,
      getServicesModel          : getServicesModel,
      getOptionsModel           : getOptionsModel,
      getSlotsModel             : getSlotsModel,
      getConfirmModel           : getConfirmModel,
      getNextAvailableSlotModel : getNextAvailableSlotModel,
      setNextAvailableSlotModel : setNextAvailableSlotModel,
      isWorkflowComplete        : isWorkflowComplete,
      isStepComplete            : isStepComplete,
      resetSteps                : initModels
    };

    return model;

    // ----------------------------
    // functions
    // ----------------------------

    function getSelectedIndex() {
      return selectedIndex;
    }

    function setSelectedIndex( val ) {
      selectedIndex = val;
    }

    function getTotalStepCount() {
      return totalStepCount;
    }

    function getNextAvailableSlotModel() {
      return slotsModel.nextAvailableSlot;
    }

    function setNextAvailableSlotModel( val ) {
      slotsModel.nextAvailableSlot = val;
    }

    function getServicesModel() {
      return servicesModel;
    }

    function getOptionsModel() {
      return optionsModel;
    }

    function getSlotsModel() {
      return slotsModel;
    }

    function getConfirmModel() {
      return confirmModel;
    }

    function filterProviders() {
      return function( provider ) {
        if ( servicesModel.selectedHospital ) {
          return _.find( provider.hospitals, { ID: servicesModel.selectedHospital.ID } );
        }
        return true;
      };
    }

    function filterServices() {
      return function( service ) {
        if ( servicesModel.selectedSpecialty ) {
          return servicesModel.selectedSpecialty.ServiceCodes.includes( service.Code );
        }
        return false;
      };
    }

    function setMatchingSlots( val ) {
      slotsModel.matchingSlots = val;
    }

    function setMatchingServices( val ) {
      servicesModel.matchingServices = val;
    }

    function setMatchingSpecialties( val ) {
      if ( val && ( val.length === 1 ) ) {
        servicesModel.selectedSpecialty = val[0];
      }
      servicesModel.matchingSpecialties = val;
    }

    function setMatchingResources( resources, locations, hospitals ) {
      servicesModel.noResourceFound = resources && ( resources.length === 0 );
      servicesModel.matchingLocations = locations;
      servicesModel.matchingHospitals = hospitals;
      if ( hospitals && hospitals.length === 1 ) {
        servicesModel.selectedHospital = hospitals[0];
      }
      if ( hospitals && locations ) {
        locations.forEach( function( location ) {
          var hospital = _.find( hospitals, { ID: location.HospitalID } );
          if ( !hospital.locations ) {
            hospital.locations = [location];
          }
          else {
            hospital.locations.push( location );
          }
        } );
      }
      optionsModel.matchingResources = resources;
      if ( resources ) {
        var codeToProviderMap = {};
        optionsModel.matchingProviders = resources.reduce( function( providers, resource ) {
          var location = _.find( locations, { ID: resource.LocationID } );
          var hospital = _.find( hospitals, { ID: location.HospitalID } );
          var provider = codeToProviderMap[resource.Code];
          resource.location = location;
          resource.hospital = hospital;
          if ( !provider ) {
            provider = {
              Code       : resource.Code,
              Description: resource.Description,
              resources  : [resource],
              locations  : [location],
              hospitals  : [hospital]
            };
            providers.push( provider );
            codeToProviderMap[resource.Code] = provider;
          }
          else {
            provider.resources.push( resource );
            provider.locations.push( location );
            provider.hospitals.push( hospital );
          }
          return providers;
        }, [] );
      }
      else {
        optionsModel.matchingResources = null;
      }
    }

    function isWorkflowComplete() {
      return _.every( models, function( model ) {
        log.debug( '...model', model );
        log.debug( '...complete', model.isComplete( model ) );
        return model.isComplete( model );
      } );
    }

    function isStepComplete( step ) {
      var model = _.find( models, { step: step } );
      var retVal = model && model.isComplete( model );
      log.debug( '...step', step );
      log.debug( '...models', models );
      log.debug( '...model', model );
      log.debug( '...retVal', retVal );
      return retVal;
    }

    function initModels() {
      selectedIndex = 0;
      totalStepCount = 4;
      models = [{
        isComplete           : function( that ) { return that && that.selectedService && that.selectedHospital; },
        step                 : 0,
        selectedLocation     : null,
        selectedHospital     : null,
        selectedService      : null,
        selectedSpecialy     : null,
        matchingSpecialities : [],
        matchingServices     : [],
        matchingHospitals    : [],
        matchingLocations    : [],
        matchingResources    : [],
        noResourceFound      : false,
        showOptions          : false,
        selectedProvider     : null,
        matchingProviders    : [],
        timeRanges           : [],
        monday               : false,
        tuesday              : false,
        wednesday            : false,
        thursday             : false,
        friday               : false,
        saturday             : false,
        sunday               : false,
        startDate            : null,
        hiddenDays           : {},
        minDate              : moment().add( 1, 'd' ).format( 'YYYY-MM-DD' ),
        maxDate              : moment().add( 90, 'd' ).format( 'YYYY-MM-DD' ),
        selectedTimeRange    : null
      }, {
        step             : 1,
        currentStateModel: {
          ViewStart           : "",
          LoadFromCurrentState: 0
        },
        nextAvailableSlot: null,
        isComplete       : function( that ) { return that && ( that.selectedSlot ); },
        matchingSlots    : [],
        dateFetchInfos   : {},
        fetchMore        : false,
        selectedSlot     : null,
        maxDate          : moment().add( 90, 'd' ).format( 'YYYY-MM-DD' )
      }, {
        step                 : 2,
        isComplete           : function( that ) { return true; },
        ConfirmationComments : ""
      }];
      servicesModel = models[0];
      optionsModel = models[0];
      slotsModel = models[1];
      confirmModel = models[2];

      totalStepCount = 3;

    }

  }// END CLASS

  // ----------------------------
  // injection
  // ----------------------------
  angular.module( 'hspcAppointments' )
   .factory( 'hspcBookAppointmentModel', hspcBookAppointmentModel );

} )();
