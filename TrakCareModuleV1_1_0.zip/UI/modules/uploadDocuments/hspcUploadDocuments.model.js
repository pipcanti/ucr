/**
 * Created by Trevor Hudson on 06/01/15.
 *
 *  Updated by ematt on 1/11/2019
 */

( function() {
  'use strict';

  angular.module( 'hspcMyDocuments' )
    .factory( 'hspcUploadDocumentsModel', hspcUploadDocumentsModel );

  function hspcUploadDocumentsModel( $translate ) {

    var tableConfig = {
      rowTemplate: 'app/templates/tableRow.html',
      columns    : [
        {
          key  : 'UploadTime',
          title: 'ISC_DATE',
          type : 'dateWithTime'
        },
        {
          key  : 'Category',
          title: 'ISC_CATEGORY'
        },
        {
          key  : 'Title',
          title: 'ISC_DESCRIPTION'
        }
      ]
    };

    var model = {
      hspcUploadDocumentsModel              : hspcUploadDocumentsModel,
      tableConfig                           : tableConfig,
    };

    return model;

  }// END CLASS
} )
();
