/**
 * Created by ematt on 1/10/2019.
 */

( function() {

  'use strict';

  angular
    .module( 'hspcMyDocuments', ['ui.router', 'isc.common'] )

    /* @ngInject */
    .config( function( iscStateProvider, $urlRouterProvider ) {
      iscStateProvider.state( getStates() );
      $urlRouterProvider.when( '/myDocuments', destroySessionIfActivating );

      /* @ngInject */
      function destroySessionIfActivating( iscSessionModel, iscCookieManager ) {
        // if redirected here from partway through activation, destroy that temporary session
        if ( iscSessionModel.isActivatingUser() ) {
          iscCookieManager.set( 'noRedirect', 1 );
          iscSessionModel.destroy();
        }
        return 'myDocuments/forms';
      }
    } );

  function getStates() {
    return {
      'authenticated.myDocuments': {
        url           : 'myDocuments',
        state         : 'authenticated.myDocuments',
        templateUrl   : 'layout/secondaryNavigation.html',
        translationKey: 'ISC_DOCUMENTS_USER_TITLE',
        controller    : 'secondaryNavigationController as secondNavCtrl',
        roles         : ['user', 'proxy'],
        displayOrder  : 5,
        resolve       : /* @ngInject */ {
          languageService: function( hspcLanguageService ) {
            return hspcLanguageService;
          },
          secondLevelTabs: function( iscNavContainerModel, languageService ) {
            var tabs = [
              {
                translationKey: 'ISC_MY_FORMS_NAV_TITLE',
                state         : 'authenticated.myDocuments.myForms',
                displayOrder  : 0
              },
              {
                translationKey: 'ISC_UPLOAD_DOCUMENTS_USER_TITLE',
                state         : 'authenticated.myDocuments.uploadDocuments',
                displayOrder  : 1
              }
            ];

            iscNavContainerModel.setSecondaryNav( tabs );

            return tabs;
          },

          secondLevelTasks: function( iscNavContainerModel ) {
            iscNavContainerModel.setSecondaryNavTasks( [] );
            return [];
          }
        }
      },

      'authenticated.myDocuments.myForms': {
        url        : '/forms',
        state      : 'authenticated.myDocuments.myForms',
        templateUrl: 'myDocuments/myForms/hspcMyForms.html',
        controller : 'hspcMyFormsController as myFormsCtrl',
        roles      : ['user', 'proxy'],
        resolve    : /* @ngInject */ {
          apiTableData: function( hspcMyFormsDataService ) {
            return hspcMyFormsDataService.getAllFormsData();
          },

          help: function( $log, hspcHelpModel ) {
            return hspcHelpModel.updateHelp( 'myForms', 'home' );
          },

          customContent: function( hspcCustomContentModel ) {
            var contentKeys = [
              'content-my-forms'
            ];

            return hspcCustomContentModel.getContentItems( contentKeys );
          }
        }
      },

      'authenticated.myDocuments.uploadDocuments': {
        url        : '/upload',
        state      : 'authenticated.myDocuments.uploadDocuments',
        templateUrl: 'uploadDocuments/hspcUploadDocuments.html',
        controller : 'hspcUploadDocumentsController as udCtrl',
        roles      : ['user', 'proxy'],
        resolve    : /* @ngInject */  {
          apiTableData   : function( hspcApi, hspcCordovaHelper, hspcAppSessionStorageHelper, iscHttpapi, apiHelper) {
            var params    = {},
                isCordova = hspcCordovaHelper.isCordova();

            if ( isCordova ) {
              params.includeCSPToken = 1;
            }
			
			var apiConfig = apiHelper.getConfigUrl();
            return iscHttpapi.get( apiConfig + '/trakcare/patient',params ).then( function( response ) {
              if ( isCordova ) {
                if ( response.CSPToken ) {
                  hspcAppSessionStorageHelper.set( 'CSPToken', response.CSPToken );
                }
              }
              return response;
            } );
          },
          attachmentTypes: function( hspcApi ) {
            return hspcApi.get( {}, 'documents/patient/categories' );
          },
          contentFiles   : function( hspcCustomContentModel ) {
            var contentKeys = [
              'content-upload-docs-main',
              'content-upload-docs-upload-dialog',
              'content-upload-docs-edit-details',
              'content-upload-docs-replace',
              'content-upload-docs-history'
            ];

            return hspcCustomContentModel.getContentItems( contentKeys );
          }
        }
      }
    };
  }
} )();
