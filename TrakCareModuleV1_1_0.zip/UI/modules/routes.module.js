/**
 * Created by thudson on 3/24/16.
 */

( function() {
  'use strict';
  angular
    .module( 'routes', [
      'ngResource',
      'hspcLanguageService',
      'tmh.dynamicLocale',
      'hspcActivate',
      'hspcScrollService',
      'hspcConstants',
      'hspcCordova',
      'hspcShareRecords',
      'hspcHealthRecords',
      'hspcMyAccount',
      'hspcMessages',
      'hspcMomentPicker',
      'hspcLibrary',
      'hspcMyDocuments',
      'hspcCalendar',
      'hspcInfoPages',
      'hspcMyBills',
      'hspcHome',
      'hspcForms',
      'hspcAppointments',
      'layout',
      'login',
      'clientTemplate',
      'decorators',
      'app.config'
    ] );
} )();
