/**
 * Created by hzou on 12/11/15.
 */

( function() {
  'use strict';

  var appConfig = getConfig();

  angular
    .module( 'app.config', ['isc.states'] )
    .config( config )
    .constant( 'appConfig', appConfig );

  function config( hspcStateAuthorizationProvider ) {
    if ( appConfig.customConfigUrl ) {
      // Since the application expects full config to be there before it runs.
      // Leveraging $.ajax to makes a SYNCHRONOUS call to get the external config and update the config
      // before the application starts.
      $.ajax( {
        method: "GET",
        url   : getCustomConfigUrl(),
        async : false //SYNCHRONOUS
      } )
        .done( function( externalConfig ) {
          var disabledOptions         = JSON.parse( externalConfig );
          var workbenchDisabledStates = hspcStateAuthorizationProvider.getDisabledStates( disabledOptions );
          var disabledForAllUsers     = _.union( workbenchDisabledStates, _.get( appConfig, 'rolePermissions["*"]', [] ) );

          _.set( appConfig, 'rolePermissions["*"]', disabledForAllUsers );
          _.set( appConfig, 'OAuth2SessionInterval', _.get( disabledOptions, "OAuth2SessionInterval" ) );
        } );
    }
  }

  /**
   * constructs the fully qualified url path based on api config and customConfigUrl
   * @returns {string}
   */
  function getCustomConfigUrl() {
    var api           = appConfig.api,
        isApiRelative = !api.protocol || !api.hostname || !api.port;
    return isApiRelative ?
      [api.path, "/", appConfig.customConfigUrl].join( '' )
      : [api.protocol, "://", api.hostname, ":", api.port, "/", api.path, "/", appConfig.customConfigUrl].join( '' );
  }

  /*========================================
   =              app config               =
   ========================================*/
  function getConfig() {
    return {
      'customConfigUrl'   : 'application/settings',
      'production'        : false,
      'sourceMaps'        : false,
      'useExtendedCharset': true,

      'session': {
        'authStatusUrl': 'auth/status'
      },

      'api': {
        'path': 'api/v1'
      },

      moduleApi: {
        'forms'   : {
          'path': 'api/v1/forms/definitions/hscomm'
        },
        'formList': {
          'path': 'api/v1/forms'
        },
        'formData': {
          'path': 'api/v1/forms/data/hscomm'
        }
      },

      formats: {
        date: {
          shareMyRecords       : 'YYYY-MM-DD',
          healthRecordsTimeline: 'YYYY-MM-DD',
          healthRecordsCharts  : 'YYYY/MM/DD',
          inQuicker            : 'YYYY-MM-DD',
          longDate             : 'LLL'
        }
      },

      /*      tableSort: {
       defaultReverseNewestFirst: '=?',
       sortFieldReverse: '=?' || false
       },*/

      forms: {
        'defaultDisplayField': 'Description',
        'updateOn'           : 'default',
        'fieldLayout'        : {
          'breakpoints': [
            'small',
            'medium',
            'large',
            'xlarge'
          ],
          'classes'    : {
            'columns'   : '{{breakpoint}}-up-{{columns}}',
            'percentage': 'formly-field-{{breakpoint}}-{{percentage}}'
          }
        }
      },

      languages   : [
        {
          'displayName': 'English',
          'fileName'   : 'en-gb'
        }
      ],
      rtlLanguages: ['ar-ae'],

      appVersion: {
        client   : '1.0',
        // updated via gulp at build time
        'release': '%appVersion.release%',
        'build'  : '%appVersion.build%',
        'change' : '%appVersion.change%'
      },

      /*
       formerly 'userPermittedTabs'
       NOTE that the allowed states are handled within the modules themselves,
       so this is used to override and exclude those you want to remove
       */
      rolePermissions: {
        '*'        : ['!unauthenticated.clientTemplate.*','!authenticated.home','!unauthenticated.calendar','!authenticated.healthRecords','!authenticated.shareRecords','!unauthenticated.library','!authenticated.myDocuments.*'], // all users
        'user'     : ['!authenticated.myAccount.devices'], // authenticated users
        'proxy'    : ['!authenticated.myAccount.devices'], // proxy users
        'proxyOnly': ['!authenticated.myAccount.devices']  // proxy-only users
      },

      home: {
        commonTasks: [
          {
            label: 'ISC_MESSAGES_MEDICAL_QUESTION',
            route: 'authenticated.messages.medicalQuestion',
            icon : 'svg/isc-conversation-icons.html'
          },
          {
            label: 'ISC_REQUEST_APPOINTMENT',
            route: 'authenticated.messages.requestAppointment',
            icon : 'svg/isc-calendar.html'
          },
          {
            label: 'ISC_VIEW_LAB_RESULTS',
            route: 'authenticated.healthRecords.LabOrders',
            icon : 'svg/isc-list.html'
          },
          {
            label: 'ISC_VIEW_MY_MEDICATION',
            route: 'authenticated.healthRecords.Medications',
            icon : 'svg/isc-capsules.html'
          },
          {
            label: 'ISC_DOWNLOAD_SEND_RECORDS',
            route: 'authenticated.shareRecords',
            icon : 'svg/isc-share-square.html'
          },
          {
            label: 'ISC_VIEW_MY_APPLICATIONS',
            route: 'authenticated.myAccount.applications',
            icon : 'svg/isc-task-arrow.html'
          }
        ]
      },

      messages: {
        appointmentTypes: [
          {
            value   : 'PrimaryCare',
            label   : 'ISC_PRIMARY_CARE',
            allTypes: [
              {
                value         : 'AnnualExam',
                label         : 'ISC_ANNUAL_PHYSICAL',
                reason        : '',
                reasonRequired: false
              },
              {
                value         : 'NewConcern',
                label         : 'ISC_NEW_CONCERN',
                reason        : '',
                reasonRequired: true
              },
              {
                value         : 'FollowUp',
                label         : 'ISC_FOLLOW_UP',
                reason        : '',
                reasonRequired: true
              },
              {
                value         : 'p4',
                label         : 'ISC_OTHER',
                reason        : '',
                reasonRequired: true
              }
            ]
          },
          {
            value   : 'Specialist',
            label   : 'ISC_SPECIALIST',
            allTypes: [
              {
                value         : 'NewConcern',
                label         : 'ISC_NEW_CONCERN',
                reason        : '',
                reasonRequired: true
              },
              {
                value         : 'FollowUp',
                label         : 'ISC_FOLLOW_UP',
                reason        : '',
                reasonRequired: true
              },
              {
                value         : 'Other',
                label         : 'ISC_OTHER',
                reason        : '',
                reasonRequired: true
              }
            ]
          },
          {
            value   : 'LabWork',
            label   : 'ISC_LABWORK',
            allTypes: [
              {
                value         : 'Referral',
                label         : 'ISC_REFERRAL',
                reason        : '',
                reasonRequired: true
              },
              {
                value         : 'FollowUp',
                label         : 'ISC_FOLLOW_UP',
                reason        : '',
                reasonRequired: true
              },
              {
                value         : 'Other',
                label         : 'ISC_OTHER',
                reason        : '',
                reasonRequired: true
              }
            ]
          }
        ]
      },

      healthRecords: {
        hiddenCategories : ['authenticated.healthRecords.DeviceObservations'],
        tableSortSettings: [
          {}
        ]
      },

      sso: {
        /*
          List of states that should be visible from the SSO login page
          If a state is in the list AND it is launched from the SSO login
          UI, the UI will ensure that it doesn't allow the patient to access
          the main application.
        */
        restrictedInfoStates: [
          'unauthenticated.info.aboutUs',
          'unauthenticated.info.help',
          'unauthenticated.info.legal',
          'unauthenticated.info.termsDisplay'
        ]
      },

      'devlogWhitelist': [],
      'devlogBlacklist': []
    };
  }
} )();
