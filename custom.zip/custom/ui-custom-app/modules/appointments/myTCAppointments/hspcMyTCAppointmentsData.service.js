/**
 *  Created by sroux on 1/08/2020.
 */

( function() {
  "use strict";

  angular
    .module( "hspcAppointments" )
    .factory(
      "hspcMyTCAppointmentsDataService",
      hspcMyTCAppointmentsDataService
    );

  /* @ngInject */
  function hspcMyTCAppointmentsDataService(
    devlog,
    hspcApi
  ) {
    var log = devlog.channel( "hspcMyTCAppointmentsDataService" );
    log.logFn( "LOADED" );

    var service = {
      fetchAppointments: fetchAppointments,
      cancelAppointment: cancelAppointment
    };

    return service;

    // ----------------------------
    // functions
    // ----------------------------

    function fetchAppointments() {
      return hspcApi
        .get( {}, "trakcare/booking/appointments" )
        .then( function( response ) {
          return response.Appointments;
        } );
    }

    function cancelAppointment( appt, patientMsg ) {
      var params = {};
      params.Slot = {
        UniqueSlotRefNum   : appt.UniqueSlotRefNum,
        UniqueBookingRefNum: appt.UniqueBookingRefNum
      };
      params.Action = "Cancel";
      params.Remarks = patientMsg;
      return hspcApi
        .post( {
          data: params
        }, "trakcare/booking/slots/" + appt.UniqueSlotRefNum )
        .then( function( response ) {
          return response;
        } );
    }
  } //END CLASS
} )();
