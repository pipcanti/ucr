/**
 * Created by hzou on 12/13/15.
 */

( function() {

  'use strict';

  angular
    .module( 'hspcHome', ['ui.router', 'isc.common'] )

    .config( function( iscStateProvider, $urlRouterProvider, STATIC_USERS ) {
      $urlRouterProvider.when( '', '/home' );
      $urlRouterProvider.when( '/', '/home' );
      $urlRouterProvider.when( '/home', goToAuthHomeIfLoggedIn );

      /* @ngInject */
      function goToAuthHomeIfLoggedIn( iscSessionModel ) {
        // if unauth, no redirect necessary
        if ( !iscSessionModel.isAuthenticated() ) {
          return false;
        }
        else {
          var user = iscSessionModel.getCurrentUser();
          // if redirected here from partway through activation, destroy that temporary session
          if ( _.isEqual( user, STATIC_USERS.activatingUser ) ) {
            iscSessionModel.destroy();
            return false;
          }
          // if hasLoginRequirements, redirect to homeWithLoginRequirements
          else if ( user.userRole === 'userWithLoginRequirements' ) {
            return '/homeWithLoginRequirements';
          }
          // else go to homeLoggedIn
          return '/homeLoggedIn';
        }
      }

      iscStateProvider.state( getStates( STATIC_USERS ) );
    } );

  function getStates( STATIC_USERS ) {
    return {
      'unauthenticated.home': {
        url            : 'home',
        templateUrl    : 'home/hspcHome.html',
        controller     : 'hspcHomeController as homeCtrl',
        state          : 'unauthenticated.home',
        translationKey : 'HSPC_HOME',
        roles          : ['*', STATIC_USERS.activatingUser.userRole],
        landingPageFor : ['*'],
        excludeAuthUser: true,
        displayOrder   : 1,
        resolve        : /* @ngInject */ {
          homeData: function( $log, hspcApi, hspcLanguageService, $q ) {
            // hacky fix for nexus chrome where page got stuck if resolve request was canceled by the browser
            var deferred = $q.defer();
            setTimeout( function() {
              var selectedLanguage = hspcLanguageService.selectedLanguage;
              hspcApi.get( {}, 'users/loginPage?lang=' + selectedLanguage.fileName ).then( function( res ) {
                deferred.resolve( res );
              } );
            }, 0 );
            return deferred.promise;
          },

          model: function( $log, homeData, hspcHomeModel ) {
            hspcHomeModel.setHomeData( homeData, true );
            return true;
          },

          help: function( $log, model, hspcHelpModel ) {
            return hspcHelpModel.updateHelp( 'home', 'homeNotLoggedIn' );
          },

          customContent: function( $log, help, hspcCustomContentModel ) {
            var contentKeys = [
              'content-welcome'
            ];

            return hspcCustomContentModel.getContentItems( contentKeys );
          },

          loadOnLoginComplete: function() {
            return false;
          },

          setStatusManager: function( hspcStatusService, hspcHomeModel ) {
            hspcHomeModel.setStatusManager( hspcStatusService.getStatusManager() );
            return true;
          }
        }
      },

      'unauthenticated.home.oauth2': {
        url           : '/oauth',
        templateUrl   : 'home/hspcHome.html',
        controller    : 'hspcHomeController as homeCtrl',
        state         : 'unauthenticated.home.oauth2',
        translationKey: 'HSPC_HOME',
        exclude       : true,
        roles         : ['*'],
        resolve       : /* @ngInject */ {
          loginWithOauth: function( loginService ) {
            //call auth login so the user can be logged in.
            loginService.login();
          }
        }
      },

      'unauthenticated.homeWithLoginRequirements': {
        url           : 'homeWithLoginRequirements',
        templateUrl   : 'home/hspcHome.html',
        controller    : 'hspcHomeController as homeCtrl',
        state         : 'unauthenticated.homeWithLoginRequirements',
        translationKey: 'HSPC_HOME',
        roles         : ["userWithLoginRequirements"],
        displayOrder  : 1,
        resolve       : /* @ngInject */ {
          // Automatically log out the semi-authenticated user if they go to Home
          // and still have outstanding login requirements
          logOutIfUnauthenticated: function( $window, iscSessionModel, $rootScope, AUTH_EVENTS ) {
            if ( iscSessionModel.isAuthenticated() ) {
              // Set this to avoid auto-logout detection in the nav model
              $rootScope.$emit( AUTH_EVENTS.logout );
            }
          },

          homeData: function( $log, hspcApi, hspcLanguageService ) {
            //console.log( 'unauthenticated.homeWithLoginRequirements, homeData', hspcLanguageService.selectedLanguage );
            var selectedLanguage = hspcLanguageService.selectedLanguage;
            return hspcApi.get( {}, 'users/loginPage?lang=' + selectedLanguage.fileName );
          },

          model: function( $log, homeData, hspcHomeModel ) {
            hspcHomeModel.setHomeData( homeData, true );
            return true;
          },

          help: function( $log, model, hspcHelpModel ) {
            return hspcHelpModel.updateHelp( 'home', 'homeNotLoggedIn' );
          },

          customContent: function( $log, help, hspcCustomContentModel ) {
            var contentKeys = [
              'content-welcome'
            ];

            return hspcCustomContentModel.getContentItems( contentKeys );
          },

          loadOnLoginComplete: function() {
            return false;
          },

          setStatusManager: function( hspcStatusService, hspcHomeModel ) {
            hspcHomeModel.setStatusManager( hspcStatusService.getStatusManager() );
            return true;
          }
        }
      },

      'authenticated.home': {
        url           : 'homeLoggedIn',
        templateUrl   : 'home/hspcHomeLoggedIn.html',
        controller    : 'hspcHomeController as homeCtrl',
        state         : 'authenticated.home',
        translationKey: 'HSPC_HOME',
        roles         : ["user", "proxy", "proxyOnly"],
        /* landingPageFor: ["user", "proxy", "proxyOnly"], KC COmmenting out for Appointment Booking */
        displayOrder  : 2,
        resolve       : /* @ngInject */ {
          homeData: function( $log, $q, $window, iscHttpapi, apiHelper, iscSessionModel, hspcLanguageService ) {
            var selectedLanguage = hspcLanguageService.selectedLanguage,
                deferred         = $q.defer(),
                url              = apiHelper.getUrl( 'users/0/home?lang=' + selectedLanguage.fileName );

            iscHttpapi.get( url ).then( onSuccess, onError );
            return deferred.promise;

            function onSuccess( result ) {
              deferred.resolve( result );
            }

            function onError( error ) {
              // If unauthenticated, kill the client session -- this will redirect to unauthenticated.home
              if ( error.status === 401 ) {
                $window.sessionStorage.setItem( 'isManualLogOut', true );
                iscSessionModel.destroy();
              }
              deferred.reject( error );
            }
          },

          model: function( $log, homeData, hspcHomeModel, iscSessionModel ) {
            hspcHomeModel.setHomeData( homeData, !iscSessionModel.isAuthenticated() );
            return true;
          },

          help: function( $log, model, hspcHelpModel ) {
            return hspcHelpModel.updateHelp( 'home', 'home' );
          },

          customContent: function( $log, help, hspcCustomContentModel ) {
            var contentKeys = [
              'content-welcome'
            ];

            return hspcCustomContentModel.getContentItems( contentKeys );
          },

          loadOnLoginComplete: function() {
            return true;
          },

          setStatusManager: function( hspcStatusService, hspcHomeModel ) {
            hspcHomeModel.setStatusManager( hspcStatusService.getStatusManager() );
            return true;
          }
        }
      }
    };
  }
} )();
