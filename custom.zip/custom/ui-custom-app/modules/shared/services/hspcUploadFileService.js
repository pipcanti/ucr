/**
 * Created by douglas goodman on 8/23/16.
 */

( function() {
  'use strict';

  angular
    .module( 'app' )
    .factory( 'hspcUploadFileService', hspcUploadFileService );

  /* @ngInject */
  /**
   *
   * service to scan and upload attachment to the server
   * NOTE the following convention:
   * @param fileData - the file to be scanned and uploaded
   * @param attachment - the fileData and associated metadata for display, eg {data: fileData, name: 'string', etc}
   */

  function hspcUploadFileService( devlog,
    $state,
    $rootScope,
    $filter,
    $timeout,
    $location,
    iscSpinnerModel,
    iscSessionModel,
    hspcApi,
    hspcUploadDocumentsService,
    hspcModalService,
    apiHelper,
    MODAL_EVENTS,
	iscHttpapi	) {

    // ----------------------------
    // vars
    // ----------------------------
    var log = devlog.channel( 'hspcUploadFileService' );
    log.logFn( 'LOADED' );

    var apiUrl    = apiHelper.getUrl();
	var apiConfig = apiHelper.getConfigUrl();
    var callbacks = {};

    var REJECTION_TYPES = {
      mime: 'mime',
      ext : 'ext',
      size: 'size'
    };

    var options = {
      type           : 'alert',
      title          : 'ISC_UPLOAD_DOCUMENTS_FILE_UPLOADING_TITLE',
      message        : 'ISC_UPLOAD_DOCUMENTS_FILE_UPLOADING_MSSG',
      hideOkButton   : true,
      cancelButtonTxt: 'ISC_OK_BTN'
    };

    // ----------------------------
    // class factory
    // ----------------------------
    var service = {
      allAttachments             : [],
      scannedAttachments         : [],
      attachmentFileTypes        : [],
      attachmentsWithoutMimeTypes: undefined,
      uploadToMyDocs             : false,
      addNewDocument             : addNewDocument,
      editDocument               : editDocument,
      setIDToReplace             : setIDToReplace,
      startUpload                : startUpload,
      postImageData              : postImageData,
      checkVirusScanStatus       : checkVirusScanStatus,
      uploadConfirm              : uploadConfirm,
      deleteAttachment           : deleteAttachment,
      isFileTypeAccepted         : isFileTypeAccepted,
      onTypeRejected             : onTypeRejected,
      getDocumentIDArray         : getDocumentIDArray,
      guid                       : guid,
      checkSubmission            : checkSubmission,
      getFormattedName           : getFormattedName,
      getFileExtension           : getFileExtension,
      fileSizeLimit              : 2000000,
      submissionCalls            : 0
    };

    return service;

    // ----------------------------
    // functions
    // ----------------------------

    function addNewDocument() {
      service.allAttachments.forEach( function( data ) {
        data.Title       = hspcUploadDocumentsService.descriptionField;
        data.Category    = hspcUploadDocumentsService.categoryField.label;
        data.CategoryID  = hspcUploadDocumentsService.categoryField.ID;

        //if in the ReplaceDocID is set in Upload Docs, send the replace request, then reset the doc ID
        if ( service.replaceDocID ) {
          hspcApi.post( { data: data, showLoader: false }, 'documents/patient/' + service.replaceDocID ).then( function( results ) {
              checkSubmission( results.RequestID );
            }, onError );
          service.replaceDocID = null;
        } else {
			iscHttpapi.post( apiConfig + '/trakcare/patient/submit', data, {showLoader:false} ).then( function( results  )		  {
			checkSubmission( results.RequestID, 1 );
          }, onError );
        }
      } );
    }

    function checkSubmission( docID , isTrak ) {
      if ( service.submissionCalls === 0 ) {
        hspcModalService.openModal( options );
      }
	  //If called in TrakCare context, call the API for TrakCare
	  if (isTrak){
		  var URL = apiConfig +'/trakcare/patient/status/'
	  }
	  else {
		var URL = apiConfig + '/documents/patient/status/'
	  }
		iscHttpapi.get( URL + docID, {showLoader:false} ).then( function( results  )		  {
        if ( results.SubmissionStatus === "ISC_UPLOAD_DOCUMENTS_SUBMITTED" ) {
          //remove spinner and refresh page so the document shows up
          iscSpinnerModel.subtractPendingReq( $location );
          service.submissionCalls = 0;
          $timeout( function() {
            $state.reload();
          }, 50 );
        }
        else if ( service.submissionCalls > 100 || results.SubmissionStatus === "ISC_UPLOAD_DOCUMENTS_ERROR" ) {
          //if the document fails to upload or we have more than 100 submission calls, error out
          iscSpinnerModel.subtractPendingReq( $location );
          service.submissionCalls = 0;
          $state.reload();
          onError();
        }
        else {
          //display the spinner constantly while checking the submission status
          iscSpinnerModel.addPendingReq( $location );
          $timeout( function() {
            service.submissionCalls += 1;
            checkSubmission( docID );
          }, 350 );
        }
      }, onError );
    }

    function editDocument() {
      var data         = hspcUploadDocumentsService.editDoc;
      data.Title       = hspcUploadDocumentsService.descriptionField;
      data.Category    = hspcUploadDocumentsService.categoryField.label;
      data.CategoryID  = hspcUploadDocumentsService.categoryField.ID;

      var fileID = data.ID;
      delete data.ID;

      hspcApi.post( { data: data, showLoader: false }, 'documents/patient/' + fileID ).then(  function( results ) {
        checkSubmission( results.RequestID );
      }, onError );
    }

    function onError() {
      var options = {
        type           : 'alert',
        title          : 'ISC_ALERT_RESPONSE_ERROR',
        message        : 'ISC_UPLOAD_DOCUMENTS_ERROR_MSG',
        hideOkButton   : true,
        cancelButtonTxt: 'ISC_CLOSE'
      };
      hspcModalService.openModal( options );
      $state.reload();
    }

    function setIDToReplace( ID ) {
      service.replaceDocID = ID;
    }

    function startUpload( attachment, postCallback, virusCallback, doneCallback, failCallback, cordova, file ) {
      callbacks = {
        postCallback : postCallback || _.noop,
        virusCallback: virusCallback || _.noop,
        doneCallback : doneCallback || _.noop,
        failCallback : failCallback || _.noop
      };

      service.postImageData( attachment, cordova, file );
    }

    // ------------------
    function postImageData( attachment, cordova, file ) {
      log.logFn( 'postImageData' );

      var fileData = attachment.data;
      log.debug( '... attachment', attachment );
      log.debug( '... fileData', fileData );

      if ( !service.isFileTypeAccepted( fileData, cordova, attachment.ext, file ) ) {
        return false;
      }

      service.allAttachments.push( attachment );

      var form = new FormData();//jshint ignore:line
      form.append( 'filename', attachment.name );

      if ( cordova ) {
        form.append( 'file', dataURItoBlob( fileData ) );
      }
      else {
        form.append( 'file', fileData );
      }

      var postXHR = new XMLHttpRequest();//jshint ignore:line
      postXHR.open( 'POST', apiUrl + 'documents/upload', true );
      postXHR.send( form );

      postXHR.addEventListener( 'progress', onPostProgress );
      postXHR.addEventListener( 'load', onPostLoad );
      postXHR.addEventListener( 'error', onPostError );
      postXHR.addEventListener( "abort", onPostError );
      postXHR.upload.addEventListener( "abort", onPostError );

      function onPostProgress( evt ) {
        log.debug( '... progress', evt );
        attachment.percentLoaded = Math.round( evt.loaded / evt.total * 100 );
        log.debug( '... photo.percentLoaded', attachment.percentLoaded );
        callbacks.postCallback( attachment );
        keepSessionAlive();
      }

      function onPostLoad( evt ) {
        // when upload is done,
        ///start virus scan status
        log.logFn( 'onPostLoad' );
        log.debug( '... evt', evt );

        var myResult = JSON.parse( postXHR.responseText );
        log.debug( '... myResult', myResult );

        if ( myResult.error ) {
          onPostError( myResult.error );
        }
        else {
          attachment.DocumentID = myResult.DocumentID;
          service.checkVirusScanStatus( attachment );
          callbacks.postCallback( attachment );
        }

        attachment.percentLoaded = 100;

        // clean up listeners
        postXHR.removeEventListener( 'progress', onPostProgress );
        postXHR.removeEventListener( 'load', onPostLoad );
        postXHR.removeEventListener( 'error', onPostError );
        postXHR.removeEventListener( "abort", onPostError );
        postXHR.upload.removeEventListener( "abort", onPostError );

      }

      function onPostError( error ) {
        // when upload fail,
        ///start virus scan status
        log.logFn( 'onPostError' );
        log.debug( '... error', error );

        if ( Object.prototype.toString.call( error ) === '[object ProgressEvent]' ) {
          error = null;
        }

        attachment.scanned = false;
        deleteAttachment( attachment );
        var popupOptions = {
          title  : 'ISC_MESSAGES_UPLOAD_ERROR_TITLE',
          message: error || 'ISC_MESSAGES_UPLOAD_ERROR_TEXT',

          hideCancelButton: true,
          okCallback      : _.noop
        };

        $rootScope.$broadcast( MODAL_EVENTS.showAlertPopup, popupOptions );

        callbacks.failCallback( attachment );

        // clean up listeners
        postXHR.removeEventListener( 'progress', onPostProgress );
        postXHR.removeEventListener( 'load', onPostLoad );
        postXHR.removeEventListener( 'error', onPostError );
        postXHR.removeEventListener( "abort", onPostError );
        postXHR.upload.removeEventListener( "abort", onPostError );
      }
    }

    // ------------------
    function checkVirusScanStatus( attachment ) {
      log.logFn( 'checkVirusScanStatus' );
      log.debug( '...attachment', attachment );

      var virusXHR = new XMLHttpRequest();//jshint ignore:line
      virusXHR.open( 'get', apiUrl + 'documents/status/' + attachment.DocumentID,
        true );

      //TODO this area needs a crap ton of testing
      //for example this right now will hang in a loop if we don't eventually get back a not scanned
      virusXHR.addEventListener( 'load', onVirusLoad );
      virusXHR.addEventListener( 'error', onScanFail );

      virusXHR.send();

      function onVirusLoad( evt ) {
        log.debug( '...virus load', evt );

        var result = JSON.parse( virusXHR.responseText );
        log.debug( '...result', result );

        if ( result.ScanStatus === 'IN_PROCESS' ) {
          log.debug( '...virus load cont' );
          $timeout( service.checkVirusScanStatus( attachment ), 2000 );
          callbacks.virusCallback( attachment );

        }
        else if ( result.ScanStatus === 'REQUIRED_SCAN_NOT_PERFORMED' ) {
          log.debug( '...virus scanner not configured' );
          virusXHR.removeEventListener( 'load', onVirusLoad );
          onScanNotPerformed( evt );
        }
        else if ( result.ScanStatus === 'PASS' || result.ScanStatus === 'NOT_SCANNED' ) {
          log.debug( '...virus load complete' );
          attachment.scanned = true;
          service.scannedAttachments.push( attachment );
          virusXHR.removeEventListener( 'load', onVirusLoad );
          callbacks.doneCallback( attachment );
        }
        else {
          onScanFail( evt );
        }

        keepSessionAlive();
      }

      function onScanFail( evt ) {
        log.debug( '...virus load', evt );
        attachment.scanned = false;
        deleteAttachment( attachment );
        var popupOptions = {
          title           : 'ISC_MESSAGES_SCAN_FAILED_TITLE',
          message         : 'ISC_MESSAGES_SCAN_FAILED_MSG',
          hideCancelButton: true,
          okCallback      : _.noop
        };

        $rootScope.$broadcast( MODAL_EVENTS.showAlertPopup, popupOptions );

        virusXHR.removeEventListener( 'error', onScanFail );

        callbacks.failCallback( attachment );

      }

      function onScanNotPerformed( evt ) {
        log.debug( '...virus load', evt );
        attachment.scanned = false;
        deleteAttachment( attachment );
        var popupOptions = {
          title           : 'ISC_MESSAGES_UPLOAD_ERROR_TITLE',
          message         : 'ISC_MESSAGES_NO_UPLOAD_TEXT',
          hideCancelButton: true,
          okCallback      : _.noop
        };

        $rootScope.$broadcast( MODAL_EVENTS.showAlertPopup, popupOptions );

        callbacks.failCallback( attachment );

      }
    }

    // ------------------
    function uploadConfirm( fileData, okCallback ) {
      log.logFn( 'uploadConfirm' );

      if ( !iscSessionModel.isAuthenticated() ) {
        return;
      }

      var mssg = $filter( 'translate' )( 'ISC_MESSAGES_UPLOAD_FILE_MSSG' );
      mssg += fileData.name ? ': ' + fileData.name + '?' : '?';

      var popupOptions = {
        title  : 'ISC_MESSAGES_UPLOAD_FILE_TITLE',
        message: mssg,

        okCallback    : okCallback,
        cancelCallback: _.noop
      };

      $rootScope.$broadcast( MODAL_EVENTS.showAlertPopup, popupOptions );
    }

    // ------------------
    function deleteAttachment( attachment ) {
      log.logFn( 'deleteAttachment' );
      var idx = _.findIndex( service.allAttachments, attachment );
      var idx2 = _.findIndex( service.scannedAttachments, attachment );


      if ( idx >= 0 ) {
        service.allAttachments.splice( idx, 1 );
        service.scannedAttachments.splice( idx2, 1 );
      }
    }

    // ------------------
    function isFileTypeAccepted( fileData, cordova, extension, file ) {
      log.logFn( 'isFileTypeAccepted' );

      var ext           = getFileExtension( fileData.name ),
          type          = fileData.type,
          rejectionType = REJECTION_TYPES.ext,
          size          = fileData.size,
          acceptable    = false;

      if ( cordova ) {
        ext = extension;
        if ( file ) {
          type = file.type;
          size = file.size;
        }
      }

      log.debug( '... fileData', fileData );
      log.debug( '... ext', ext );
      log.debug( '...type', type );

      // if there is neither a MIME type nor an extension, return false
      if ( !type && !ext ) {
        log.debug( '...NEITHER' );
        rejectionType = REJECTION_TYPES.ext;
        acceptable    = false;
      }

      else if ( service.uploadToMyDocs && size > service.fileSizeLimit ) {
        log.debug( '...File too large for HealthShare Unified Care Record' );
        rejectionType = REJECTION_TYPES.size;
        acceptable    = false;
      }

      else {
        var extensions = _.map( service.attachmentFileTypes, function( type ) {
          return type.Name;
        } );
        //log.debug( '...extensions', extensions );

        var extensionAccepted = _.some( extensions, function( e ) {
          return e.toLowerCase() === ( ext && ext.toLowerCase() );
        } );
        log.debug( '...extensionAccepted', extensionAccepted );

        var mimeTypes = _.flatten( _.map( service.attachmentFileTypes, function( type ) {
          return type.Types;
        } ) );
        //log.debug( '...mimeTypes', mimeTypes );

        var mimeTypeAccepted = _.some( mimeTypes, function( t ) {
          return t.toLowerCase() === ( type && type.toLowerCase() );
        } );

        log.debug( '...mimeTypeAccepted', mimeTypeAccepted );

        // if attachments without MIME types are allowed,
        // make sure the extension is allowed
        log.debug( '...attachmentsWithoutMimeTypes', !!service.attachmentsWithoutMimeTypes );


        if ( cordova ) {
          rejectionType = REJECTION_TYPES.ext;
          // note that we fall back on MIME type to handle issues of jpg vs jpeg
          acceptable    = extensionAccepted || mimeTypeAccepted;
        } else {
          if ( service.attachmentsWithoutMimeTypes && service.uploadToMyDocs ) {
            rejectionType = REJECTION_TYPES.ext;
            acceptable    = extensionAccepted;
          }
          else if ( service.attachmentsWithoutMimeTypes && !type ) {
            rejectionType = REJECTION_TYPES.ext;
            acceptable    = extensionAccepted;
          }
          // otherwise if the MIME type is required, see if it is accepted
          else {
            rejectionType = REJECTION_TYPES.mime;
            acceptable    = mimeTypeAccepted;
          }
        }
      }

      if ( !acceptable ) {
        service.onTypeRejected( rejectionType );
      }

      return acceptable;
    }

    // ------------------
    function onTypeRejected( reason ) {
      log.logFn( 'onTypeRejected' );

      var mssg;
      if ( reason === REJECTION_TYPES.size ) {
        mssg = $filter( 'translate' )( 'ISC_MESSAGES_UPLOAD_SIZE_REJECTED_MSSG' );
      }

      else {
        mssg = $filter( 'translate' )( 'ISC_MESSAGES_UPLOAD_REJECTED_MSSG' );

        // we are rejecting for either ext or mime, so list the acceptable extensions
        mssg += ' ' + $filter( 'translate' )( 'ISC_MESSAGES_ACCEPTABLE_TYPES_MSSG' );
        var types = _.sortBy( service.attachmentFileTypes, 'Name' );
        mssg += '<ul class="fileTypeList">';
        _.forEach( types, function( type ) {
          mssg += '<li>' + type.Name + '</li>';
        } );
        mssg += '</ul>';
      }


      var popupOptions = {
        title  : 'ISC_MESSAGES_UPLOAD_REJECTED_TITLE',
        message: mssg,

        cancelButtonText: 'ISC_CLOSE',
        hideOkButton    : true,
        cancelCallback  : _.noop
      };

      $rootScope.$broadcast( MODAL_EVENTS.showAlertPopup, popupOptions );
    }

    // ------------------
    function getDocumentIDArray() {
      log.logFn( 'getDocumentIDArray' );

      var arr = _.map( service.allAttachments, function( attachment ) {
        return attachment.DocumentID;
      } );

      log.debug( '...arr', arr );
      return arr;
    }

    function formatName( name, index ) {
      var lastIndex = name.lastIndexOf( "." );

      if ( lastIndex === -1 ) {
        return name + '(' + index + ')';
      }

      var fileName = name.substring( 0, name.lastIndexOf( "." ) );
      var fileExt  = name.substring( name.lastIndexOf( "." ) );

      return fileName + '(' + index + ')' + fileExt;
    }

    function getFormattedName( name ) {

      var groups = _.groupBy( service.allAttachments, "originalName" );

      // no duplicates found
      if ( !groups[name] ) {
        return name;
      }

      // 1 duplicate is found and has same display name
      if ( groups[name].length === 1 && groups[name][0].name === name ) {
        return formatName( name, 1 );
      }

      var lastIndex   = name.lastIndexOf( "." ),
          fileName    = name,
          fileExt     = "",
          regexString = '(^' + fileName + ')((\\()(\\d+)(\\))$)';

      if ( lastIndex !== -1 ) {
        fileName    = name.substring( 0, lastIndex );
        fileExt     = name.substring( lastIndex );
        regexString = '(^' + fileName + ')((\\()(\\d+)(\\))(\\' + fileExt + ')$)';
      }

      var regex = new RegExp( regexString, "i" );

      // at this point there are multiple duplicates with formatted names [xxx(n).zzz]

      /*
       *  1. Loop through the files with duplicate names
       *  2. Map the count in the formatted names
       *  3. Get the max among the mapped values
       *  4. Get formatted name with incremented value
       *  e.g. [Photo(1).jpg, Photo(8).jpg, Photo(5).jpg, Photo(7).jpg] => [1,8,5,7]
       *        max([1,8,5,7])=> 8 :: Photo(9).jpg
       */

      var maxIndex = _.chain( groups[name] )
        .map( function( obj ) {
          var matches = obj.name.match( regex );
          return ( !matches ? 0 : parseInt( matches[4], 10 ) );
        } ).max().value();

      return fileName + "(" + ( maxIndex + 1 ) + ")" + fileExt;
    }

    // ----------------------------
    // private functions
    // ----------------------------

    function getFileExtension( fileName ) {
      var idx = _.lastIndexOf( fileName, '.' );
      var ext = idx > -1 ? fileName.substr( idx + 1 ) : null;
      log.debug( '... ext', ext );

      return ext;
    }

    function keepSessionAlive() {
      return hspcApi.get( { showLoader: false }, '_ping' ); // keep the session alive
    }

    var pictureSource;   // picture source
    var destinationType; // sets the format of returned value

    // device APIs are available
    function onDeviceReady() {
      pictureSource   = navigator.camera.PictureSourceType;//jshint ignore:line
      destinationType = navigator.camera.DestinationType;//jshint ignore:line
    }

    //these two functions make unique ID
    function guid() {
      return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
        s4() + '-' + s4() + s4() + s4();
    }

    function s4() {
      return Math.floor( ( 1 + Math.random() ) * 0x10000 )
        .toString( 16 )
        .substring( 1 );
    }

    // convert base64/URLEncoded data component to raw binary data held in a string
    // this is key to getting base64 stuff to work with form data
    function dataURItoBlob( dataURI ) {
      log.logFn( 'dataURItoBlob' );
      log.debug( '...dataURI', dataURI );

      var byteString;
      if ( dataURI.split( ',' )[0].indexOf( 'base64' ) >= 0 ) {
        byteString = atob( dataURI.split( ',' )[1] );//jshint ignore:line
      }
      else {
        byteString = unescape( dataURI.split( ',' )[1] );//jshint ignore:line
      }

      // separate out the mime component
      var mimeString = dataURI.split( ',' )[0].split( ':' )[1].split( ';' )[0];

      // write the bytes of the string to a typed array
      var ia = new Uint8Array( byteString.length );
      for ( var i = 0; i < byteString.length; i++ ) {
        ia[i] = byteString.charCodeAt( i );
      }

      return new Blob( [ia], { type: mimeString } );//jshint ignore:line
    }

  }//END CLASS

} )();
