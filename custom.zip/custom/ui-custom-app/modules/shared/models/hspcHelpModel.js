/**
 * Created by douglas goodman on 9/6/15.
 */

( function() {
  'use strict';

  angular.module( 'app' )
    .factory( 'hspcHelpModel', hspcHelpModel );

  // ----------------------------
  // model

  function hspcHelpModel( devlog,
    $state,
    hspcAppSessionStorageHelper,
    hspcApi,
    hspcLanguageService ) {

    // ----------------------------
    // vars
    // ----------------------------

    var log = devlog.channel( 'hspcHelpModel' );
    log.debug( 'hspcHelpModel LOADED' );

    var currentHelp = '';

    var allParams = {

      calendar: {
        area: 'area-calendar',

        home     : 'calendar-home',
        timeRange: 'calendar-range'
      },

      healthRecords: {
        area: 'area-ehr',

        searchResults: 'ehr-term-search',
        home         : 'ehr-home',

        //My Personal Information
        personalInfo: 'ehr-basic',

        advancedirectives       : 'ehr-advancedirectives',
        advancedirectivesDetails: 'ehr-advancedirectives-details',

        allergies       : 'ehr-allergies',
        allergiesDetails: 'ehr-allergies-details',

        //My Health Alerts
        alerts       : 'ehr-alerts',
        alertsDetails: 'ehr-alerts-details',

        appointments       : 'ehr-appointments',
        appointmentsDetails: 'ehr-appointments-details',

        //My Plan of Care
        careplans       : 'ehr-careplans',
        careplansDetails: 'ehr-careplans-details',

        conditions       : 'ehr-problems',
        conditionsDetails: 'ehr-problem-details',

        // Day synopsis
        date: 'ehr-date-details',

        //My Wearable Device
        device           : 'ehr-device',
        deviceList       : 'ehr-device-list',
        deviceListDetails: 'ehr-device-list-details',
        deviceChart      : 'ehr-device-chart',

        //My Hospital Diagnoses
        diagnoses       : 'ehr-diagnoses',
        diagnosesDetails: 'ehr-diagnoses-details',

        //My Reports
        documents       : 'ehr-documents',
        documentsDetails: 'ehr-documents-details',

        //My Visits
        encounters       : 'ehr-encounters',
        encountersDetails: 'ehr-encounters-details',

        familyhistories       : 'ehr-familyhistories',
        familyhistoriesDetails: 'ehr-familyhistories-details',

        goals       : 'ehr-goals',
        goalsDetails: 'ehr-goals-details',

        //My Insurance
        guarantors       : 'ehr-guarantors',
        guarantorsDetails: 'ehr-guarantors-details',

        //My Past Illnesses
        illnesshistories       : 'ehr-illnesshistories',
        illnesshistoriesDetails: 'ehr-illnesshistories-details',

        healthconcerns       : 'ehr-health-concerns',
        healthconcernsDetails: 'ehr-health-concerns-details',

        immunizations       : 'ehr-immunizations',
        immunizationsDetails: 'ehr-immunizations-details',

        labs             : 'ehr-labs',
        labResults       : 'ehr-lab-results',
        labResultsDetails: 'ehr-lab-results-details',
        labResultsChart  : 'ehr-lab-results-chart',

        medications       : 'ehr-medications',
        medicationsDetails: 'ehr-medications-details',

        observations          : 'ehr-observations',
        observationList       : 'ehr-observation-list',
        observationListDetails: 'ehr-observation-list-details',
        observationsChart     : 'ehr-observations-chart',

        //My Vitals
        otherorders       : 'ehr-otherorders',
        otherordersDetails: 'ehr-otherorders-details',

        physicalexams       : 'ehr-physicalexams',
        physicalexamsDetails: 'ehr-physicalexams-details',

        //My Conditions
        problems       : 'ehr-problems',
        problemsDetails: 'ehr-problems-details',

        //My Medical Procedures
        procedures       : 'ehr-procedures',
        proceduresDetails: 'ehr-procedures-details',

        programs       : 'ehr-programs',
        programsDetails: 'ehr-programs-details',

        //My Care Team
        providers       : 'ehr-providers',
        providersDetails: 'ehr-providers-details',

        // summary
        timelineSummary: 'history-new',
        timelineDate   : 'ehr-date-details',
        timelineRange  : 'ehr-history-range',

        //My Radiology Results
        radorders       : 'ehr-radorders',
        radordersDetails: 'ehr-radorders-details',

        //My Instructions
        recommendations       : 'ehr-recommendations',
        recommendationsDetails: 'ehr-recommendations-details',

        referrals       : 'ehr-referrals',
        referralsDetails: 'ehr-referrals-details',

        //My Social Habits
        socialhistories       : 'ehr-socialhistories',
        socialhistoriesDetails: 'ehr-socialhistories-details'
      },

      home: {
        area: 'area-home',

        homeNotLoggedIn  : 'home',
        login            : 'login',
        home             : 'home',
        forgotPassword   : 'forgot-password',
        resetPassword    : 'forgot-password-reset-password',
        securityQuestion : 'forgot-password-security-question',
        enrollTerms      : 'enroll-terms',
        enroll           : 'enroll',
        enrollActivate   : 'enroll-activate',
        enrollSecondary  : 'enroll-secondary',
        enrollPassword   : 'enroll-setpassword',
        enrollSecurity   : 'enroll-securityquestions',
        enrollPreferences: 'enroll-confirmpreferences'
      },

      library: {
        area: 'area-library',

        healthDictionary: 'library-dictionary',
        news            : 'library-news',
        subscriptions   : 'library-channels',
        forms           : 'library-forms',
        questionnaires  : 'library-questionnaires'
      },

      messages: {
        area: 'area-messages',

        inbox       : 'messages-inbox',
        inboxDetails: 'messages-inbox-details',

        outbox       : 'messages-outbox',
        outboxDetails: 'messages-outbox-details',

        archivedInbox       : 'messages-archived-inbox',
        archivedInboxDetails: 'messages-archived-inbox-details',

        archivedOutbox       : 'messages-archived-outbox',
        archivedOutboxDetails: 'messages-archived-outbox-details',

        reply: 'messages-reply',

        medicalProviderSearch: 'messages-medical-providerSearch',
        medical              : 'messages-medical',

        generalProviderSearch: 'messages-general-providerSearch',
        general              : 'messages-general',

        billingProviderSearch: 'messages-billing-providerSearch',
        billing              : 'messages-billing',

        testresultProviderSearch: 'messages-testresult-providerSearch',
        testresult              : 'messages-testresult',

        sent: 'message-sent-complete',

        appointment        : 'messages-appointment',
        appointmentType    : 'appointment-type',
        appointmentTime    : 'appointment-time',
        appointmentContact : 'appointment-contact',
        appointmentConfirm : 'appointment-confirm',
        appointmentComplete: 'appointment-complete',

        searchSchedule: 'inquicker-search-schedule',
        searchProvider: 'inquicker-search-provider',
        fullSchedule  : 'inquicker-display-full-schedule',

        refill        : 'messages-refill',
        refillLocation: 'refill-provider',
        refillPharmacy: 'refill-pharmacy',
        refillContact : 'refill-contact',
        refillConfirm : 'refill-confirm',

        referral        : 'messages-referral',
        referralType    : 'referral-provider',
        referralReason  : 'referral-reason',
        referralTime    : 'referral-time',
        referralContact : 'referral-contact',
        referralConfirm : 'referral-confirm',
        referralComplete: 'referral-complete'
      },

      myAccount: {
        area: 'area-account',

        summary                 : 'account-home',
        summaryExternalLogin    : 'external-login',
        history                 : 'account-history',
        changePassword          : 'account-changePassword',
        changeSecurityQuestions : 'account-changeSecurityQuestions',
        preferences             : 'account-preferences',
        preferencesExternalLogin: 'account-preferences-external-login',
        wearableDevices         : 'account-wearableDevices',
        viewProxy               : 'account-viewProxy',
        applications            : 'account-viewMyApplications'
      },

      shareRecords: {
        area: 'area-ehr',

        download        : 'ehr-download',
        wait            : 'ehr-download-wait',
        view            : 'ehr-download-view',
        transmit        : 'ehr-transmit',
        transmitComplete: 'ehr-transmit-complete'
      },

      sso: {
        area: 'area-sso',

        saml: 'sso-saml'
      },

      uploadDocuments: {
        area: 'area-upload-documents',

        main   : 'main',
        dialog : 'upload-dialog',
        replace: 'replace',
        history: 'history',
        edit   : 'edit-details'
      },

      myBills: {
        area: 'area-mybills',
        home: ''
      },

      myForms: {
        area: 'area-my-forms',

        home: ''
      },

      appointments: {
        area: 'area-appointments',

        'book-1': 'book-1',
        'book-2': 'book-2',
        'book-3': 'book-3',

        home: ''
      }
    };

    var currentParams = {};

    // ----------------------------
    // class factory
    // ----------------------------
    var model = {
      currentParams : currentParams,
      showHelpButton: true,

      getCurrentHelp: getCurrentHelp,
      setCurrentHelp: setCurrentHelp,
      updateHelp    : updateHelp,

      getShowHelpButton: getShowHelpButton,

      getParams: getParams,

      getKeyForTimeline: getKeyForTimeline
    };

    return model;

    // ----------------------------
    // functions
    // ----------------------------

    function getKeyForTimeline( viewState, confType ) {

      //we return same result for 'define' for any viewState so no sense in testing, just return value
      if ( viewState === 'define' ) {
        return 'searchResults';
      }

      //for most others we only have details
      switch ( confType ) {
        case 'AdvanceDirectives':
          return 'advancedirectivesDetails';

        case 'Alerts':
          return 'alertsDetails';

        case 'Allergies':
          return 'allergiesDetails';

        case 'Appointments':
          return 'appointmentsDetails';

        case 'CarePlans':
          return 'careplansDetails';

        case 'DeviceObservations':
          return 'deviceListDetails';

        case 'Diagnoses':
          return 'diagnosesDetails';

        case 'Documents':
          return 'documentsDetails';

        case 'Encounters':
          return 'encountersDetails';

        case 'FamilyHistories':
          return 'familyhistoriesDetails';

        case 'Goals':
          return 'goalsDetails';

        case 'HealthConcerns':
          return 'healthconcernsDetails';

        case 'IllnessHistories':
          return 'illnesshistoriesDetails';

        case 'Insurances':
          return 'guarantorsDetails';

        case 'Immunizations':
          return 'immunizationsDetails';

        case 'Instructions':
          return 'recommendationsDetails';

        //but there's always an exception
        case 'LabOrders':
          switch ( viewState ) {
            case 'details':
              return 'labResults';
            case 'details2':
              return 'labResultsDetails';
            case 'chart':
              return 'labResultsChart';
          }
          break;

        case 'Medications':
          return 'medicationsDetails';

        case 'Observations':
          switch ( viewState ) {
            case 'details':
              return 'observationListDetails';
            case 'observation':
              return 'observationList';
            case 'chart':
              return 'observationsChart';
          }
          break;

        case 'OtherOrders':
          return 'otherordersDetails';

        case 'PhysicalExams':
          return 'physicalexamsDetails';

        case 'Problems':
          return 'problemsDetails';

        case 'Procedures':
          return 'proceduresDetails';

        case 'Programs':
          return 'programsDetails';

        case 'Providers':
          return 'providersDetails';

        case 'RadOrders':
          return 'radordersDetails';

        case 'Referrals':
          return 'referralsDetails';

        case 'SocialHistories':
          return 'socialhistoriesDetails';
      }

    }

    function getCurrentHelp() {
      log.debug( 'hspcHelpModel.getCurrentHelp', currentHelp );
      return currentHelp;
    }

    function setCurrentHelp( val ) {
      log.debug( 'hspcHelpModel.setCurrentHelp', val );
      currentHelp = val;
    }

    // ----------------------------
    function updateHelp( area, key ) {
      log.debug( 'hspcHelpModel.updateHelp', area, key );

      model.currentParams = model.getParams( area, key );
      log.debug( '...model.currentParams', model.currentParams );

      if ( !model.currentParams ) {
        return;
      }

      log.debug( '...model.currentParams.lang', model.currentParams.lang );

      model.currentParams.lang = hspcLanguageService.getSelectedLanguage().fileName;

      return hspcApi.get( {
        showLoader: false,
        params    : model.currentParams
      }, 'content/popup/help/public' ).then(
        function( response ) {
          log.debug( '...success', response );
          var helpContent = {
            area        : area,
            key         : key,
            lang        : hspcLanguageService.getSelectedLanguage().fileName,
            actualHelpId: response.actualHelpId,
            content     : response.content
          };
          log.debug( '...helpContent', helpContent );

          model.setCurrentHelp( helpContent );

          // this backSref is mainly to verify authorization of parent state
          var backSref = $state.current.name;

          if ( $state.current.name === '' ) { // if refreshed while on help, take backsref from stored params
            backSref = hspcAppSessionStorageHelper.getHelpParams().backSref;
          }

          // store these on sesssion storage so that the help page can be refreshed
          var storedHelpParams = {
            area    : area,
            key     : key,
            lang    : hspcLanguageService.getSelectedLanguage().fileName,
            backSref: backSref
          };
          log.debug( '...storedHelpParams', storedHelpParams );

          return hspcAppSessionStorageHelper.setHelpParams( storedHelpParams );
        } );
    }

    // ----------------------------
    function getParams( areaId, keyId ) {
      log.debug( 'hspcHelpModel.getParams' );
      log.debug( '...areaId', areaId );
      log.debug( '...keyId', keyId );

      var section = _.get( allParams, areaId );

      var area = !!section && section.area;
      var key  = !!section && _.get( section, keyId );

      // allows empty string to be appended to the area (needed for My Bills)
      if ( !area || !( typeof key === "string" ) ) {
        return null;
      }

      var params = {
        area: area,
        key : key
      };

      log.debug( '...area', area );
      log.debug( '...key', key );
      log.debug( '...params', params );

      return params;
    }

    // ----------------------------
    function getShowHelpButton( stateName ) {
      switch ( stateName ) {
        case 'unauthenticated.info.help':
        case 'unauthenticated.info.aboutUs':
        case 'unauthenticated.info.legal':
        //case 'unauthenticated.info.terms':
        case 'unauthenticated.info.termsDisplay':
        case 'unauthenticated.info.validateToken':
          return false;

        default:
          return true;
      }
    }

  }//END CLASS

} )();
