/**
 * Created by doug31415 on 3/25/2016, 11:40:23 AM.
 */

( function() {

  'use strict';

  angular
    .module( 'hspcMyAccount', ['ui.router', 'isc.common'] )

    /* @ngInject */
    .config( function( iscStateProvider, $urlRouterProvider ) {
      $urlRouterProvider.when( '/myAccount', '/myAccount/summary' );

      iscStateProvider.state( getStates() );
    } );

  var secondaryNav = [
    {
      'state'         : 'authenticated.myAccount.summary',
      'translationKey': 'ISC_MY_ACCT_SUMMARY_BTN',
      'displayOrder'  : 1
    }, 
    {
      'state'         : 'authenticated.myAccount.history',
      'translationKey': 'ISC_MY_ACCT_HISTORY_BTN',
      'displayOrder'  : 2
    },
    {
      'state'         : 'authenticated.myAccount.password',
      'translationKey': 'ISC_MY_ACCT_CHANGE_PASSWORD_BTN',
      'displayOrder'  : 3
    },
    {
      'state'         : 'authenticated.myAccount.securityQuestions',
      'translationKey': 'ISC_MY_ACCT_CHANGE_SECURITY_QUESTIONS',
      'displayOrder'  : 4
    },
    {
      'state'         : 'authenticated.myAccount.devices',
      'translationKey': 'ISC_MY_ACCT_DEVICES_BTN',
      'displayOrder'  : 5
    },
    /*{
      'state'         : 'authenticated.myAccount.proxies',
      'translationKey': 'ISC_MY_ACCT_PROXIES_BTN',
      'displayOrder'  : 6
    },*/
    /*{
      'state'         : 'authenticated.myAccount.preferences',
      'translationKey': 'ISC_ACCT_PREFERENCES_TITLE',
      'displayOrder'  : 7
    },*/
    {
      'state'         : 'authenticated.myAccount.applications',
      'translationKey': 'ISC_MY_ACCT_APPS_BTN',
      'displayOrder'  : 8
    }
  ];

  var secondaryNavExternalCredentials = [
    {
      'state'         : 'authenticated.myAccount.summary',
      'translationKey': 'ISC_MY_ACCT_SUMMARY_BTN',
      'displayOrder'  : 1
    },
    {
      'state'         : 'authenticated.myAccount.history',
      'translationKey': 'ISC_MY_ACCT_HISTORY_BTN',
      'displayOrder'  : 2
    },
    {
      'state'         : 'authenticated.myAccount.devices',
      'translationKey': 'ISC_MY_ACCT_DEVICES_BTN',
      'displayOrder'  : 3
    },
    {
      'state'         : 'authenticated.myAccount.proxies',
      'translationKey': 'ISC_MY_ACCT_PROXIES_BTN',
      'displayOrder'  : 4
    },
    {
      'state'         : 'authenticated.myAccount.preferences',
      'translationKey': 'ISC_ACCT_PREFERENCES_TITLE',
      'displayOrder'  : 5
    },
    {
      'state'         : 'authenticated.myAccount.applications',
      'translationKey': 'ISC_MY_ACCT_APPS_BTN',
      'displayOrder'  : 6
    }
  ];


  function rejectIfExcluded() {
    return reject;

    /* @ngInject */
    function reject( $q, AUTH_EVENTS ) {
      var state    = this.state;
      var deferred = $q.defer();
      if ( _.find( secondaryNav, { state: state, exclude: true } ) ) {
        deferred.reject( {
          from : state,
          code : AUTH_EVENTS.notAuthorized,
          error: 'User is not authorized'
        } );
      } else {
        deferred.resolve();
      }
      return deferred.promise;
    }
  }

  function getStates() {
    return {
      'authenticated.myAccount': {
        url           : 'myAccount',
        state         : 'authenticated.myAccount',
        templateUrl   : 'layout/secondaryNavigation.html',
        translationKey: 'HSPC_MY_ACCOUNT',
        controller    : 'secondaryNavigationController as secondNavCtrl',
        roles         : ['user', 'proxy', 'proxyOnly'],
        displayOrder  : 8,
        resolve       : /* @ngInject */ {
          excludeTabs: function( iscCustomConfigService, hspcApi, hspcModalService, $state, hspcMyAccountModel, hspcOAuth2SessionService ) {
            return hspcApi.get( {}, 'users/0/securityQuestions' ).then(
              function( results ) {
                var excludeConfig         = {};
                var hideSecurityQuestions = !_.get( results, 'MinimumSecurityQuestionCount', 0 );

                if ( hideSecurityQuestions ) {
                  excludeConfig['authenticated.myAccount.securityQuestions'] = true;
                }
                return hspcMyAccountModel.getSMARTAppsFromServer().then( function( result ) {
                  if ( result.length === 0 ) {
                    excludeConfig['authenticated.myAccount.applications'] = true;
                  }
                  return excludeConfig;
                }, function( error ) {
                  return excludeConfig;
                } );
              },
              function( error ) {
                var options = {
                  type           : 'logout',
                  title          : 'ISC_ALERT_SESSION_TIMEOUT',
                  message        : 'ISC_ALERT_SESSION_LOGOUT_MSG',
                  hideOkButton   : true,
                  cancelButtonTxt: 'ISC_CLOSE'
                };
                hspcModalService.openModal( options );
                hspcOAuth2SessionService.removeOAuthCookieAndEndInterval();
                $state.go( 'unauthenticated.home' );
              }
            );
          },

          secondLevelTabs: function( iscNavContainerModel, excludeTabs, hspcLoginHelper ) {
            var secondaryNavArray = _.cloneDeep( secondaryNav );
            if ( hspcLoginHelper.getLoginTypeIsExternal() ) {
              secondaryNavArray = secondaryNavExternalCredentials;
            }
            _.forEach( excludeTabs, function( value, state ) {
              var nav     = _.find( secondaryNavArray, { state: state } ) || {};
              nav.exclude = value;
            } );
            iscNavContainerModel.setSecondaryNav( secondaryNavArray );
            return secondaryNavArray;
          },

          secondLevelTasks: function( iscNavContainerModel ) {
            iscNavContainerModel.setSecondaryNavTasks( [] );
            return [];
          },

          customContent: function( secondLevelTabs, hspcCustomContentModel ) {
            var contentKeys = [
              // change password
              'content-myaccount-changepassword',

              // change securityquestions
              'content-myaccount-changesecurityquestions',

              // proxy users
              'content-myaccount-shareinformation',

              //preferences
              'content-myaccount-preferences',

              //preferences for logging in with external credentials
              'content-myaccount-preferences-external-login',

              //my SMART applications
              'content-myaccount-smartapps'
            ];

            return hspcCustomContentModel.getContentItems( contentKeys );
          }
        }
      },

      'authenticated.myAccount.summary': {
        url        : '/summary',
        state      : 'authenticated.myAccount.summary',
        templateUrl: 'myAccount/templates/hspcMyAccountSummary.html',
        controller : 'hspcMyAccountController as myAcctCtrl',
        roles      : ['user', 'proxy', 'proxyOnly'],
        resolve    : /* @ngInject */{
          accountSummary: function( customContent, hspcApi ) {
            return hspcApi.get( {}, 'users/0/accountSummary' );
          },

          model: function( accountSummary, hspcMyAccountModel ) {
            hspcMyAccountModel.setAccountSummary( accountSummary );
          },

          help: function( model, hspcHelpModel, hspcLoginHelper ) {
            if ( hspcLoginHelper.getLoginTypeIsExternal() ) {
              hspcHelpModel.updateHelp( 'myAccount', 'summaryExternalLogin' );
            } else {
              hspcHelpModel.updateHelp( 'myAccount', 'summary' );
            }
          }
        }
      },

      'authenticated.myAccount.history': {
        url        : '/history',
        state      : 'authenticated.myAccount.history',
        templateUrl: 'myAccount/templates/hspcMyAccountHistory.html',
        controller : 'hspcMyAccountController as myAcctCtrl',
        roles      : ['user', 'proxy', 'proxyOnly'],
        resolve    : /* @ngInject */{
          history: function( customContent, hspcApi ) {
            return hspcApi.get( {}, 'users/0/accountHistory' );
          },

          model: function( history, hspcMyAccountModel ) {
            hspcMyAccountModel.setHistory( history );
          },

          help: function( model, hspcHelpModel ) {
            hspcHelpModel.updateHelp( 'myAccount', 'history' );
          }
        }
      },

      'authenticated.myAccount.password': {
        url        : '/password',
        state      : 'authenticated.myAccount.password',
        templateUrl: 'myAccount/templates/hspcMyAccountPassword.html',
        controller : 'hspcMyAccountController as myAcctCtrl',
        roles      : ['user', 'proxyOnly'],
        resolve    : /* @ngInject */{
          help: function( customContent, hspcHelpModel ) {
            hspcHelpModel.updateHelp( 'myAccount', 'changePassword' );
          }
        }
      },

      'authenticated.myAccount.securityQuestions': {
        url        : '/securityQuestions',
        state      : 'authenticated.myAccount.securityQuestions',
        templateUrl: 'myAccount/templates/hspcMyAccountSecurityQuestions.html',
        controller : 'hspcMyAccountController as myAcctCtrl',
        roles      : ['user', 'proxyOnly'],
        resolve    : /* @ngInject */{
          rejectIfExcluded: rejectIfExcluded(),

          data: function( customContent, hspcApi, rejectIfExcluded ) {
            return hspcApi.get( {}, 'users/0/securityQuestions' );
          },

          model: function( data, hspcEditSecurityQuestionService, hspcValidationHelper ) {
            hspcEditSecurityQuestionService.setSecurityQuestionData( data );

            // Resets the edit state of the security questions
            hspcEditSecurityQuestionService.cancelEditQuestion();

            return hspcValidationHelper.loadValidationData();
          },

          help: function( model, hspcHelpModel, hspcEditSecurityQuestionService,
            hspcValidationHelper ) {
            hspcEditSecurityQuestionService.securityAnswerValidationData = hspcValidationHelper.securityAnswerValidationData;
            return hspcHelpModel.updateHelp( 'myAccount', 'changeSecurityQuestions' );
          },

          language: function( $translate, hspcLanguageService, iscCustomConfigService, hspcInfoPagesModel, hspcModalService ) {
            var appLanguages  = _.get( iscCustomConfigService.getConfig(), 'languages', [] );
            var preferredLang = _.find( appLanguages, ['fileName', hspcInfoPagesModel.PreferredUILanguage] );

            // if preferred language is different from the language for security questions, alert the user
            if ( preferredLang && ( hspcLanguageService.getSelectedLanguage().fileName !== preferredLang.fileName ) ) {
              var message = $translate.instant( "ISC_SECURITY_QUESTIONS_LANG_1",
                {
                  selectedLanguage : $translate.instant( hspcLanguageService.getSelectedLanguage().displayName ),
                  preferredLanguage: $translate.instant( preferredLang.displayName )
                } );

              var message2 = $translate.instant( "ISC_SECURITY_QUESTIONS_LANG_2",
                { selectedLanguage: $translate.instant( hspcLanguageService.getSelectedLanguage().displayName ) } );

              var options = {
                title            : 'ISC_SECURITY_QUESTIONS_LANG_TITLE',
                message          : message,
                secondaryMessages: message2,
                cancelCallback   : _.noop,
                cancelButtonTxt  : 'ISC_CLOSE',
                hideOkButton     : true
              };

              hspcModalService.openModal( options );
            }
          }
        }
      },

      'authenticated.myAccount.proxies': {
        url        : '/proxies',
        state      : 'authenticated.myAccount.proxies',
        templateUrl: 'myAccount/templates/hspcMyAccountProxies.html',
        controller : 'hspcMyAccountController as myAcctCtrl',
        roles      : ['user', 'proxy', 'proxyOnly'],
        resolve    : /* @ngInject */{
          proxies: function( customContent, hspcApi ) {
            return hspcApi.get( {}, 'users/0/proxyData' );
          },
          model  : function( proxies, hspcMyAccountModel ) {
            hspcMyAccountModel.setAccountProxies( proxies );
          },
          help   : function( model, hspcHelpModel ) {
            hspcHelpModel.updateHelp( 'myAccount', 'viewProxy' );
          }
        }
      },

      'authenticated.myAccount.preferences': {
        url        : '/preferences',
        state      : 'authenticated.myAccount.preferences',
        templateUrl: 'myAccount/templates/hspcMyAccountPreferences.html',
        controller : 'hspcMyAccountController as myAcctCtrl',
        roles      : ['user', 'proxyOnly'],
        resolve    : /* @ngInject */{
          preferences: function( customContent, hspcApi ) {
            return hspcApi.get( {}, 'users/0/communication' );
          },
          providers  : function( customContent, hspcApi ) {
            return hspcApi.get( {}, 'application/phoneProviders' );
          },
          languages  : function( customContent, hspcApi ) {
            return hspcApi.get( {}, 'application/languages' );
          },
          model      : function( preferences, providers, languages, hspcMyAccountModel ) {
            hspcMyAccountModel.setPreferences( preferences );
            hspcMyAccountModel.setProviders( providers );
            hspcMyAccountModel.setLanguages( languages );
          },
          help       : function( model, hspcHelpModel, hspcLoginHelper ) {
            if ( hspcLoginHelper.getLoginTypeIsExternal() ) {
              hspcHelpModel.updateHelp( 'myAccount', 'preferencesExternalLogin' );
            } else {
              hspcHelpModel.updateHelp( 'myAccount', 'preferences' );
            }
          }
        }
      },

      'authenticated.myAccount.devices'     : {
        url        : '/devices',
        state      : 'authenticated.myAccount.devices',
        templateUrl: 'myAccount/templates/hspcMyAccountDevices.html',
        controller : 'hspcMyAccountController as myAcctCtrl',
        roles      : ['user', 'proxy'],
        resolve    : /* @ngInject */{
          rejectIfExcluded: rejectIfExcluded(),

          devices: function( customContent, hspcApi, rejectIfExcluded ) {
            // add timestamp to bust caching
            return hspcApi.get( {}, 'users/0/devices?timestamp=' + Date.now() ).then(
              _.noop(), function( results ) {
                return results;
              } );
          },
          model  : function( devices, hspcMyAccountModel ) {
            _.set( hspcMyAccountModel, 'errorMessage', _.get( devices, 'data.error' ) );
            hspcMyAccountModel.setAccountDevices( devices.RegisteredDevices );
          },
          help   : function( model, hspcHelpModel ) {
            hspcHelpModel.updateHelp( 'myAccount', 'wearableDevices' );
          }
        }
      },
      'authenticated.myAccount.applications': {
        url        : '/applications',
        state      : 'authenticated.myAccount.applications',
        templateUrl: 'myAccount/templates/hspcMyAccountSMARTApps.html',
        controller : 'hspcMyAccountController as myAcctCtrl',
        roles      : ['user', 'proxy', 'proxyOnly'],
        resolve    : /* @ngInject */{
          applications: function( customContent, hspcApi ) {
            return hspcApi.get( {}, 'applications/smart-apps' );
          },
          appUseInfo  : function( hspcApi ) {
            return hspcApi.get( {}, 'users/0/applications' );
          },
          model       : function( applications, hspcMyAccountModel, appUseInfo ) {
            hspcMyAccountModel.setAllSMARTApps( applications.SMARTApps );
            hspcMyAccountModel.setSMARTApps( applications.SMARTApps, appUseInfo.Applications );
          },
          help        : function( model, hspcHelpModel ) {
            hspcHelpModel.updateHelp( 'myAccount', 'applications' );
          }
        }
      }
    };
  }
} )();
